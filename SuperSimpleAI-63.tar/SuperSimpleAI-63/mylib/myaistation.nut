/**
 * This file is part of SuperSimpleAI: An OpenTTD AI.
 *
 * Author: Jaume Sabater
 *
 * It's free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 2 of the License, or
 * any later version.
 *
 * You should have received a copy of the GNU General Public License
 * with it.  If not, see <http://www.gnu.org/licenses/>.
 */

/**
 * Define the MyAIStation class which extends the AIStation functions.
 */
class MyAIStation /* extends AIStation */
{
	/**
	 * Open an airport.
	 * @param airport The airport id.
	 * @return True if it was closed, false if not.
	 */
	static function OpenAirport(airport);

	/**
	 * Close an airport.
	 * @param airport The airport id.
	 * @return True if it was opened, false if not.
	 */
	static function CloseAirport(airport);
}

function MyAIStation::OpenAirport(airport)
{
	if (AIStation.IsAirportClosed(airport)) return AIStation.OpenCloseAirport(airport);
	return false;
}

function MyAIStation::CloseAirport(airport)
{
	if (!AIStation.IsAirportClosed(airport)) return AIStation.OpenCloseAirport(airport);
	return false;
}
