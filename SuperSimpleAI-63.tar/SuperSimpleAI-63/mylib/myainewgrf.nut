/**
 * This file is part of SuperSimpleAI: An OpenTTD AI.
 *
 * Author: Jaume Sabater
 *
 * It's free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 2 of the License, or
 * any later version.
 *
 * You should have received a copy of the GNU General Public License
 * with it.  If not, see <http://www.gnu.org/licenses/>.
 */

/**
 * Define the MyAINewGRF class which extends the AINewGRF functions.
 */
class MyAINewGRF /* extends AINewGRF */
{
	/**
	 * Get Name and Version if a NewGRF id is loaded.
	 * @param id The NewGRF id.
	 * @return string with loaded NewGRF Name and Version.
	 */
	static function GetNameAndVersion(id);
}

function MyAINewGRF::GetNameAndVersion(id)
{
	if (AINewGRF.IsLoaded(id)) return AINewGRF.GetName(id) + "(" + AINewGRF.GetVersion(id) + ")";
	else return "";
}
