/**
 * This file is part of SuperSimpleAI: An OpenTTD AI.
 *
 * Author: Jaume Sabater
 *
 * It's free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 2 of the License, or
 * any later version.
 *
 * You should have received a copy of the GNU General Public License
 * with it.  If not, see <http://www.gnu.org/licenses/>.
 */

/**
 * Define the MyAIDepotList_Rail class which extends the AIDepotList functions.
 */
class MyAIDepotList_Rail extends AIDepotList
{
	constructor() {
		::AIDepotList.constructor(AITile.TRANSPORT_RAIL);
	}
}

