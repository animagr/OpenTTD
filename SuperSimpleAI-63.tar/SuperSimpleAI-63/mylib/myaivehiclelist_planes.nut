/**
 * This file is part of SuperSimpleAI: An OpenTTD AI.
 *
 * Author: Jaume Sabater
 *
 * It's free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 2 of the License, or
 * any later version.
 *
 * You should have received a copy of the GNU General Public License
 * with it.  If not, see <http://www.gnu.org/licenses/>.
 */

/**
 * Define the MyAIVehicleList_Planes class which extends the AIVehicleList functions.
 */
class MyAIVehicleList_Planes extends AIVehicleList
{
	constructor() {
		::AIVehicleList.constructor();
		this.Valuate(AIVehicle.GetVehicleType);
		this.KeepValue(AIVehicle.VT_AIR);
	}
}

