/**
 * This file is part of SuperSimpleAI: An OpenTTD AI.
 *
 * Author: Jaume Sabater
 *
 * It's free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 2 of the License, or
 * any later version.
 *
 * You should have received a copy of the GNU General Public License
 * with it.  If not, see <http://www.gnu.org/licenses/>.
 */

/**
 * Wait if we don't have money
 * @param min_money Money (plus MiniumCashNeeded) needed.
 * @ return True if success.
 */
function cBuilder::WaitForMoney(min_money)
{
	if (min_money < 0) return false;
	min_money += Banker.GetMinimumCashNeeded();
	local balance = MyAICompany.GetMyBankBalance();
	if (balance > min_money) return true;
	local count = 2500;
	while (count > 0) {
		if (Banker.GetMaxBankBalance() < min_money) {
			if (count == 2500) SuperSimpleAI.LogDebug("All Builder activities are suspended to avoid bankrupt");
			root.manager.MainLoop();
			AIController.Sleep(90);
			count--;
		} else count = -1;
	}
	if (count == 0) return false;
	return Banker.GetMoney(MyMath.Min(min_money - balance, AICompany.GetMaxLoanAmount() - AICompany.GetLoanAmount()));
}

/*
 * Demolish a tile, if we have money.
 * @param tile The tile to demolish.
 * @return true if success.
 */
function cBuilder::WaitAndDemolish(tile)
{
	cBuilder.WaitForMoney(MyAITile.GetDemolishCost(tile));
	return AITile.DemolishTile(tile);
}

/*
 * Build a rail or road bridge, if we have money.
 * @param arg1 Start tile of the bridge.
 * @param arg2 End tile of the bridge.
 * @param type AIVehicle.VT_RAIL or AIVehicle.VT_ROAD.
 * @return true if success.
 */
function cBuilder::WaitAndBuildBridge(arg1, arg2, type)
{
	if (arg1 == null || arg2 == null || type == null) return false;
	local bridgelist = AIBridgeList_Length(AIMap.DistanceManhattan(arg1, arg2) + 1);
	if (Banker.SetMinimumBankBalance(AISettings.MiniumMoneyToUseFastBridges())) bridgelist.Valuate(AIBridge.GetMaxSpeed);
	else {
		bridgelist.Valuate(AIBridge.GetPrice,AIMap.DistanceManhattan(arg1, arg2) + 1);
		bridgelist.Sort(AIList.SORT_BY_VALUE, true);
	}
	cBuilder.WaitForMoney(AIBridge.GetPrice(bridgelist.Begin(), AIMap.DistanceManhattan(arg1, arg2) + 1) + 2 * AISettings.GetBridgeHeadCost());
	return AIBridge.BuildBridge(type, bridgelist.Begin(), arg1, arg2);
}
