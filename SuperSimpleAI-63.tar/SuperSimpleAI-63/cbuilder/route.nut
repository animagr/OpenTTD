/**
 * This file is part of SuperSimpleAI: An OpenTTD AI.
 *
 * Based on code from SimpleAI, written by Brumi.
 *
 * Author: Jaume Sabater
 *
 * It's free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 2 of the License, or
 * any later version.
 *
 * You should have received a copy of the GNU General Public License
 * with it.  If not, see <http://www.gnu.org/licenses/>.
 */

/**
 * Register the new route into the database (v3).
 * @return The new route registered.
 */
function cBuilder::RegisterRoute(maxspeed = 0)
{
	local route = {
		src = null
		src2 = null
		pas = null
		dst = null
		stasrc = null
		stapas = null
		stadst = null
		homedepot = null
		otherdepot = null
		group = null
		crg = null
		extracrg = null
		vehtype = null
		railtype = null
		maxvehicles = null
		slopes = null
		cur_max_speed = null
		last_wagon = null
		last_extra_wagon = null
		last_engine = null
		last_date = null
	}
	route.src = src;
	route.src2 = src2;
	route.pas = extra_dst;
	route.dst = dst;
	route.stasrc = stasrc;
	route.stapas = stapass;
	route.stadst = stadst;
	route.homedepot = homedepot;
	route.otherdepot = otherdepot;
	route.group = group;
	route.crg = crg;
	route.extracrg = extracrg;
	route.vehtype = vehtype;
	route.railtype = AIRail.GetCurrentRailType();
	switch (vehtype) {
		case AIVehicle.VT_ROAD:
			route.maxvehicles = road_vehs;
			break;
		case AIVehicle.VT_RAIL:
			route.maxvehicles = trains;
			break;
		case AIVehicle.VT_AIR:
			route.maxvehicles = 0;
			break;
	}
	route.slopes = slopes;
	local vehlist = AIVehicleList_Group(group);
	if (vehlist.Count() == 0) route.cur_max_speed = 0;
	else route.cur_max_speed = maxspeed;
	route.last_date = AIDate.GetCurrentDate();
	root.routes.push(route);
	if (!AICargo.HasCargoClass(crg, AICargo.CC_PASSENGERS)) root.serviced.AddItem(src * 256 + crg, 0);
	if (extracrg != null) root.serviced.AddItem(src * 256 + extracrg, 0);
	root.serviced_array = MyAIList.ListToArray(root.serviced);
	root.groups.AddItem(group, root.routes.len() - 1);
	root.groups_array = MyAIList.ListToArray(root.groups);
	root.lastroute = AIDate.GetCurrentDate();
	return route;
}
