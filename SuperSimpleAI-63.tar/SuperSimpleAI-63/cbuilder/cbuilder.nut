/**
 * This file is part of SuperSimpleAI: An OpenTTD AI.
 *
 * Based on code from SimpleAI, written by Brumi.
 *
 * Author: Jaume Sabater
 *
 * It's free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 2 of the License, or
 * any later version.
 *
 * You should have received a copy of the GNU General Public License
 * with it.  If not, see <http://www.gnu.org/licenses/>.
 */

class cBuilder
{
		DIR_NE = 2;
		DIR_NW = 0;
		DIR_SE = 1;
		DIR_SW = 3;

		root = null; // Reference to the AI instance

		src = null;	// The source (StationID/TownID) selected
		src2 = null;	// The second source (StationID/TownID)
		dst = null;	// The destination (StationID/TownID) selected
		stasrc = null;	  // Source station
		stadst = null;	  // Destination station
		stapass = null;	  // Passing station (if it is allowed)
		homedepot = null; // The depot at the source station
		otherdepot = null; // The depot at the destination station
		railtype = null;
		slopes = null;    // Slopes (coded) from source to detination

		crglist = null; // The list of possible cargoes
		crg = null; // The cargo selected to be transported
		extracrg = null; // Extra cargo for dual cargo trains
		srclist = null; // The list of sources for the given cargo
		dstlist = null; // The list of destinations for the given source
		srctile_tested = null; // Tested tiles where stations can be built.
		passtile_tested = null;
		dsttile_tested = null;
		extra_src = null; // Extra source industry for dual cargo trains
		extra_srccrg = null; // Extra source cargo for dual cargo trains
		extra_dst = null; // Extra destination industry for dual cargo trains
		statile = null;
		sta2tile = null;
		stapasstile = null;
		double_pass_station = null;
		deptile = null;
		deppasstile = null; // The tile of the station; The tile of the depot
		stavector = null;
		starvector = null;
		staoption = null; // Where exit is placed in station
		depoption = null; // Where depot is placed in station
		staoffset1 = null;
		staoffset2 = null; // Offset to place correctly passing lanes
		stafront = null;
		staextracrg = null; // Double cargo station
		sta2front = null;
		depfront = null; // The tile in front of the station; The tile in front of the depot
		passstafront = null;
		passdepfront = null; // The tile in front of the station; The tile in front of the depot
		statop = null;
		stabottom = null;
		frontfront = null; // Some variables needed to build a train station
		passfrontfront = null;
		front1 = null;
		front2 = null;
		passfront1 = null;
		passfront2 = null;
		lane2 = null;
		morefront = null; // Some more variables needed to build a double rail station
		passmorefront = null;
		stationdir = null; // The direction of the station
		srcistown = null;
		passistown = null;
		dstistown = null; // Whether the source is a town; Whether the destination is a town
		srcplace = null;
		passplace = null;
		dstplace = null; // The place of the source (town/industry); The place of the destination (town/industry)
		group = null; // The current vehicle group
		vehtype = null; // The vehicle type selected
		double_srcsta = null; // Whether it is a double platform source station.
		double_dststa = null; // Whether it is a double platform destination station.
		trains = null; // Trains on a route
		road_vehs = null;
		holes = null;
		holestart = null;
		holeend = null; // Variables needed to correct roads which weren't built fully
		src_entry = null;
		dst_entry = null;
		pass_entry = null;
		pass_exit = null;
		src_offset = null;
		dst_offset = null;
		pass_offset = null;
		passinglanelist = null; // Passing lane starting/ending/blocking points
		ps1_entry = null; ps1_exit = null;
		ps2_entry = null; ps2_exit = null;
		ps3_entry = null; ps3_exit = null;
		ps4_entry = null; ps4_exit = null;
		ps5_entry = null; ps5_exit = null;
		ps6_entry = null; ps6_exit = null;
		ps7_entry = null; ps7_exit = null;
		ps8_entry = null; ps8_exit = null;
		ps9_entry = null; ps9_exit = null;
		ps10_entry = null; ps10_exit = null;
		ps11_entry = null; ps11_exit = null;
		ps12_entry = null; ps12_exit = null;
		ps13_entry = null; ps13_exit = null;
		ps14_entry = null; ps14_exit = null;
		ps15_entry = null; ps15_exit = null; // Passing lane starting/ending points
		bl1_entry = null ; bl1_exit = null;
		bl2_entry = null ; bl2_exit = null;
		bl3_entry = null ; bl3_exit = null;
		bl4_entry = null ; bl4_exit = null;
		bl5_entry = null ; bl5_exit = null;
		bl6_entry = null ; bl6_exit = null;
		bl7_entry = null ; bl7_exit = null;
		bl8_entry = null ; bl8_exit = null;
		bl9_entry = null ; bl9_exit = null;
		bl10_entry = null ; bl10_exit = null;
		bl11_entry = null ; bl11_exit = null;
		bl12_entry = null ; bl12_exit = null;
		bl13_entry = null ; bl13_exit = null;
		bl14_entry = null ; bl14_exit = null;
		bl15_entry = null ; bl15_exit = null; // Block tiles to aviod 90 grade turns
		segment = 0;
		builddepot1 = null;
		builddepot2 = null;
		recursiondepth = null; // The recursion depth used to catch infinite recursions
		path = null;
		constructor(that) {
			root = that;
			passinglanelist = MyAITileList_Passinglane();;
			src_entry = [null, null]; dst_entry = [null, null];
			pass_entry = [null, null]; pass_exit = [null, null];
			src_offset = [null, null]; dst_offset = [null, null]; pass_offset = [null, null];
			ps1_entry = [null, null]; ps1_exit = [null, null];
			ps2_entry = [null, null]; ps2_exit = [null, null];
			ps3_entry = [null, null]; ps3_exit = [null, null];
			ps4_entry = [null, null]; ps4_exit = [null, null];
			ps5_entry = [null, null]; ps5_exit = [null, null];
			ps6_entry = [null, null]; ps6_exit = [null, null];
			ps7_entry = [null, null]; ps7_exit = [null, null];
			ps8_entry = [null, null]; ps8_exit = [null, null];
			ps9_entry = [null, null]; ps9_exit = [null, null];
			ps10_entry = [null, null]; ps10_exit = [null, null];
			ps11_entry = [null, null]; ps11_exit = [null, null];
			ps12_entry = [null, null]; ps12_exit = [null, null];
			ps13_entry = [null, null]; ps13_exit = [null, null];
			ps14_entry = [null, null]; ps14_exit = [null, null];
			ps15_entry = [null, null]; ps15_exit = [null, null];
			bl1_entry = [null, null]; bl1_exit = [null, null];
			bl2_entry = [null, null]; bl2_exit = [null, null];
			bl3_entry = [null, null]; bl3_exit = [null, null];
			bl4_entry = [null, null]; bl4_exit = [null, null];
			bl5_entry = [null, null]; bl5_exit = [null, null];
			bl6_entry = [null, null]; bl6_exit = [null, null];
			bl7_entry = [null, null]; bl7_exit = [null, null];
			bl8_entry = [null, null]; bl8_exit = [null, null];
			bl9_entry = [null, null]; bl9_exit = [null, null];
			bl10_entry = [null, null]; bl10_exit = [null, null];
			bl11_entry = [null, null]; bl11_exit = [null, null];
			bl12_entry = [null, null]; bl12_exit = [null, null];
			bl13_entry = [null, null]; bl13_exit = [null, null];
			bl14_entry = [null, null]; bl14_exit = [null, null];
			bl15_entry = [null, null]; bl15_exit = [null, null];
		}

}
