/**
 * This file is part of SuperSimpleAI: An OpenTTD AI.
 *
 * Based on code from SimpleAI, written by Brumi.
 *
 * Author: Jaume Sabater
 *
 * It's free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 2 of the License, or
 * any later version.
 *
 * You should have received a copy of the GNU General Public License
 * with it.  If not, see <http://www.gnu.org/licenses/>.
 */

/**
 * Find a cargo, a source and a destination to build a new service.
 * Builder class variables set: crglist, crg, srclist, src, dstlist, dst,
 *   srcistown, dstistown, srcplace, dstplace
 * @return True if a potential connection was found.
 */
function cBuilder::FindService()
{
	local min_prod = 50;
	local max_distance = 100;
	crglist = AICargoList();
	crglist.Valuate(AIBase.RandItem);
	// Choose a source
	foreach (icrg, dummy in crglist) {
		// Passengers only if we're using air
		if (vehtype == AIVehicle.VT_AIR && MyAICargo.IsFreightCargo(icrg)) continue;
		// Skip cargo routes if trucks and trains aren't allowed
		if (!AISettings.UseTrucks() && !AISettings.UseRail() && MyAICargo.IsFreightCargo(icrg)) continue;
		if (MyAICargo.IsFreightCargo(icrg) && !MyAICargo.IsMailCargo(icrg)) {
			// If the source is an industry
			srclist = AIIndustryList_CargoProducing(icrg);
			// Should not be built on water
			srclist.Valuate(AIIndustry.IsBuiltOnWater);
			srclist.KeepValue(0);
			// There should be some production
			srclist.Valuate(AIIndustry.GetLastMonthProduction, icrg)
			if (root.buildcounter < 9) min_prod = 100; 
			if (root.buildcounter < 4) min_prod = 150;
			srclist.KeepAboveValue(min_prod);
			// Try to avoid excessive competition
			srclist.Valuate(MyAIIndustry.GetLastMonthTransportedPercentage, icrg);
			srclist.KeepBelowValue(AISettings.GetMaxTransported());
			srcistown = false;
		} else {
			// If the source is a town
			srclist = AITownList();
			srclist.Valuate(AITown.GetLastMonthProduction, icrg);
			if (vehtype == AIVehicle.VT_AIR) srclist.KeepAboveValue(AISettings.GetAirMinProduction());
			else {
				if (!AISettings.UsePassTrains() && !AISettings.UseRegionalBuses()) continue;
				srclist.KeepAboveValue(40);
			}
			srcistown = true;
		}
		srclist.Valuate(AIBase.RandItem);
		foreach (isrc, dummy2 in srclist) {
			// Jump source if already serviced
			if (MyAICargo.IsFreightCargo(icrg) && root.serviced.HasItem(isrc * 256 + icrg)) continue;
			// Jump if an airport exists there and it has no free capacity
			if (!cBuilder.CheckExistingAirportCapacity(isrc, icrg, vehtype, true)) continue;
			if (srcistown) srcplace = AITown.GetLocation(isrc);
			else srcplace = AIIndustry.GetLocation(isrc);
			if (AICargo.GetTownEffect(icrg) == AICargo.TE_NONE || AICargo.GetTownEffect(icrg) == AICargo.TE_WATER) {
				// If the destination is an industry
				dstlist = AIIndustryList_CargoAccepting(icrg);
				dstistown = false;
				dstlist.Valuate(AIIndustry.GetDistanceManhattanToTile, srcplace);
			} else {
				// If the destination is a town
				dstlist = AITownList();
				// Some minimum population values for towns
				switch (AICargo.GetTownEffect(icrg)) {
					case AICargo.TE_FOOD:
						dstlist.Valuate(AITown.GetPopulation);
						dstlist.KeepAboveValue(100);
						break;
					case AICargo.TE_GOODS:
						dstlist.Valuate(AITown.GetPopulation);
						dstlist.KeepAboveValue(1500);
						break;
					default:
						dstlist.Valuate(AITown.GetLastMonthProduction, icrg);
						if (vehtype == AIVehicle.VT_AIR) dstlist.KeepAboveValue(AISettings.GetAirMinProduction());
						else dstlist.KeepAboveValue(40);
						break;
				}
				dstistown = true;
				dstlist.Valuate(AITown.GetDistanceManhattanToTile, srcplace);
			}
			local iveh = MyRoadVehs.ChooseRoadVeh(icrg);
			if (MyAICargo.IsFreightCargo(icrg) || !AISettings.UseLocalBuses() || iveh == null) dstlist.KeepAboveValue(AISettings.GetRoadOrRailMinDistance());
			else dstlist.KeepAboveValue(AISettings.MinLocalBusDistance());
			// Check the distance of the source and the destination
			if (vehtype == AIVehicle.VT_AIR) {
				dstlist.KeepAboveValue(AISettings.GetAirMinDistance());
				max_distance = AISettings.GetAirMaxDistance();
				// Get the maximum range of airplanes
				local max_range = MyAIEngine.GetMaximumAircraftRange();
				if (max_range > 0) {
					// maximum range is 0 if range is not supported by the plane set
					dstlist.Valuate(cBuilder.GetTownAircraftOrderDistanceToTile, srcplace);
					if (max_distance > (max_range * 0.82).tointeger()) max_distance = (max_range * 0.82).tointeger();
				}
				dstlist.KeepBelowValue(max_distance);
			} else {
				max_distance = cBuilder.RoadOrRailMaxDistance(icrg);
				if (MyAICargo.IsMailCargo(icrg)) dstlist.KeepBelowValue(AISettings.GetRoadMaxDistance(root.buildcounter));
				else dstlist.KeepBelowValue(max_distance);
			}
			dstlist.Valuate(AIBase.RandItem);
			foreach (idst, dummy3 in dstlist) {
				if (MyAICargo.IsPassengersCargo(icrg) && cBuilder.AreTownsServiced(isrc, idst)) continue;
				// Chech if the destination capacity for more planes
				if (!cBuilder.CheckExistingAirportCapacity(idst, icrg, vehtype, false)) continue;
				if (dstistown) dstplace = AITown.GetLocation(idst);
				else dstplace = AIIndustry.GetLocation(idst);
				crg = icrg;
				src = isrc;
				dst = idst;
				extracrg = null;
				return true;
			}
		}
	}
	return false;
}

/**
 * Choose a subsidy if there are some available.
 * Builder class variables set: crg, src, dst, srcistown, dstistown, srcplace, dstplace
 * @return True if a subsidy was chosen.
 */
function cBuilder::CheckSubsidies()
{
	local subs = AISubsidyList();
	// Exclude subsidies which have already been awarded to someone
	subs.Valuate(AISubsidy.IsAwarded);
	subs.KeepValue(0);
	if (subs.Count() == 0) return false;
	subs.Valuate(AIBase.RandItem);
	foreach (sub, dummy in subs) {
		crg = AISubsidy.GetCargoType(sub);
		srcistown = (AISubsidy.GetSourceType(sub) == AISubsidy.SPT_TOWN);
		src = AISubsidy.GetSourceIndex(sub);
		if (root.serviced.HasItem(src * 256 + crg)) continue;
		// Some random chance not to choose this subsidy
		if (!AIBase.Chance(AISettings.GetSubsidyChange(), 11) || (!root.use_roadvehs && !root.use_trains)) continue;
		if (srcistown) {
			srcplace = AITown.GetLocation(src);
		} else {
			srcplace = AIIndustry.GetLocation(src);
			// Jump this if there is already some heavy competition there
			if (AIIndustry.GetLastMonthTransported(src, crg) > AISettings.GetMaxTransported()) continue;
		}
		dstistown = (AISubsidy.GetDestinationType(sub) == AISubsidy.SPT_TOWN);
		dst = AISubsidy.GetDestinationIndex(sub);
		if (dstistown) {
			dstplace = AITown.GetLocation(dst);
		} else {
			dstplace = AIIndustry.GetLocation(dst);
		}
		if (!AISettings.UsePassTrains() && !AISettings.UseRegionalBuses()) continue;
		if (srcistown && dstistown && MyAICargo.IsPassengersCargo(crg) && cBuilder.AreTownsServiced(src, dst)) continue;
		// Check the distance
		if (AIMap.DistanceManhattan(srcplace, dstplace) > cBuilder.RoadOrRailMaxDistance(crg)) continue;
		if (AIMap.DistanceManhattan(srcplace, dstplace) < AISettings.GetRoadOrRailMinDistance()) continue;
		return true;
	}
	return false;
}

/**
 * Decide whether to use road or rail.
 * @return The vehicle type to use, null if there are none available.
 */
function cBuilder::RoadOrRail()
{
	local vehicles = root.use_roadvehs + root.use_trains * 2;
	switch (vehicles) {
		case 0: // neither road or rail
			return null;
			break;
		case 1: // road
			return AIVehicle.VT_ROAD;
			break;
		case 2: // rail
			if (MyAICargo.IsMailCargo(crg)) return null;
			return AIVehicle.VT_RAIL;
			break;
		case 3: // both road and rail
			local dist = AIMap.DistanceManhattan(srcplace, dstplace);
			local veh = MyRoadVehs.ChooseRoadVeh(crg);
			local wagon = MyTrains.ChooseWagon(crg, root.engineblacklist);
			if (veh == null || (MyAICargo.IsPassengersCargo(crg) && !AISettings.UseRegionalBuses() && !AISettings.UseLocalBuses()) || (MyAICargo.IsFreightCargo(crg) && !AISettings.UseTrucks())) {
				if (MyAICargo.IsMailCargo(crg) || wagon == null || (MyAICargo.IsPassengersCargo(crg) && (!AISettings.UsePassTrains() || AISettings.GetPassRailMaxDistance(root.buildcounter) == 0))) return null;
				return AIVehicle.VT_RAIL;
			}
			if (wagon == null) return AIVehicle.VT_ROAD;
			local num_wagons = cBuilder.GetTrainMaxLength(crg) * 2 - 1;
			local trainengine = MyTrains.ChooseTrainEngine(crg, dist, wagon, num_wagons, root.engineblacklist);
			if (veh == null && trainengine == null) return null;
			if (trainengine == null) return AIVehicle.VT_ROAD;
			if (MyAICargo.IsMailCargo(crg)) return AIVehicle.VT_ROAD;
			if (MyAICargo.IsPassengersCargo(crg) && dist > AISettings.GetPassRailMaxDistance(root.buildcounter)) return AIVehicle.VT_ROAD;
			if (dist > AISettings.GetRoadMaxDistance(root.buildcounter)) return AIVehicle.VT_RAIL;
			if (AISettings.IsOldStyleRailLine()) {
				if (dist < 30) return AIVehicle.VT_ROAD;
			} else {
				if (dist < 60) return AIVehicle.VT_ROAD;
			}
			if (AIBase.Chance(2, 3)) return AIVehicle.VT_ROAD;
			else return AIVehicle.VT_RAIL;
			break;
	}
}

/**
 * Return de maximum distance than rail or road can do.
 * @crg Cargo that want to travel with train or road.
 * @return The maximum distance.
 */
function cBuilder::RoadOrRailMaxDistance(crg)
{
        if (MyAICargo.IsPassengersCargo(crg)) return (MyMath.Max(AISettings.GetPassRailMaxDistance(root.buildcounter), AISettings.GetRoadMaxDistance(root.buildcounter)) * (AIBase.RandRange(7) + 3) / 10).tointeger();
        else return (MyMath.Max(AISettings.GetCargoRailMaxDistance(root.buildcounter), AISettings.GetRoadMaxDistance(root.buildcounter)) * (AIBase.RandRange(8) + 2) / 10).tointeger();
}

/**
 * Check if two towns are conected by passenger service.
 * @param towna One of the towns.
 * @param townb The other town.
 * @return True if they are serviced.
 */
function cBuilder::AreTownsServiced(towna, townb) {
	foreach (idx, route in root.routes) if (MyAICargo.IsPassengersCargo(route.crg)) {
		if ((towna == route.src && townb == route.dst) || (townb == route.src && towna == route.dst)) return true;
	}
	return false;
}
