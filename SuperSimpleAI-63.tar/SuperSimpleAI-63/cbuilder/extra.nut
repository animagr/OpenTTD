/**
 * This file is part of SuperSimpleAI: An OpenTTD AI.
 *
 * Based on code from SimpleAI, written by Brumi.
 *
 * Author: Jaume Sabater
 *
 * It's free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 2 of the License, or
 * any later version.
 *
 * You should have received a copy of the GNU General Public License
 * with it.  If not, see <http://www.gnu.org/licenses/>.
 */

/**
 * Get the slope magic key between source and destination.
 * @param src Source tile.
 * @param dst Destination tile.
 * @return 0 if it's a descending route, 1 if it's flat, 2 and 3 if it's ascending/climbing route.
 */
function cBuilder::GetSlopes(src, dst)
{
	local src_z = MyAITile.GetMaxHeight(src);
	local dst_z = MyAITile.GetMaxHeight(dst);
	if (dst_z == src_z)  return 1;
	if (dst_z - 2 > src_z) return 3;
	if (dst_z > src_z) return 2;
	return 0;
}

/**
 * And some simple functions to control loggin messages.
 */
function cBuilder::PrintLog()	{ return AISettings.GetAISetting("cBuilder_log", true); }
function cBuilder::Debug()	{ return (cBuilder.PrintLog()) ? AISettings.GetAISetting("cBuilder_log_debug", false) : false; }

