/**
 * This file is part of SuperSimpleAI: An OpenTTD AI.
 *
 * Based on code from SimpleAI, written by Brumi.
 *
 * Author: Jaume Sabater
 *
 * It's free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 2 of the License, or
 * any later version.
 *
 * You should have received a copy of the GNU General Public License
 * with it.  If not, see <http://www.gnu.org/licenses/>.
 */

/**
 * Set the name of a vehicle group.
 * @param group The GroupID of the group.
 * @param crg The cargo transported.
 * @param stasrc The source station.
 * @return True if success.
 */
function cBuilder::SetGroupName(group, crg, stasrc)
{
	local groupname = AICargo.GetCargoLabel(crg) + " - " + AIStation.GetName(stasrc);
	if (groupname.len() > 30) groupname = groupname.slice(0, 30);
	if (!AIGroup.SetName(group, groupname)) {
		// Shorten the name if it is too long (Unicode character problems)
		while (AIError.GetLastError() == AIError.ERR_PRECONDITION_STRING_TOO_LONG) {
			groupname = groupname.slice(0, groupname.len() - 1);
			AIGroup.SetName(group, groupname);
		}
	}
	return true;
}

/**
 * Get the GroupId from a RouteID.
 * @param myroute Route ID .
 * @return group Group ID.
 */
function cBuilder::GetGroupFromRoute(myroute)
{
	foreach (group, route in root.groups) {
		if (myroute == route) return group;
	}
	return -1;
}
