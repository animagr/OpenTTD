/**
 * This file is part of SuperSimpleAI: An OpenTTD AI.
 *
 * Author: Jaume Sabater
 *
 * It's free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 2 of the License, or
 * any later version.
 *
 * You should have received a copy of the GNU General Public License
 * with it.  If not, see <http://www.gnu.org/licenses/>.
 */

/**
 * Check if source and destination(s) industries still open.
 * If there are more destination stations, delete only one of them.
 * @return True if all are open or are towns, or only one destination station is deleted.
 */
function cBuilder::AreIndustriesAlive()
{
	if (!srcistown && (!MyAIIndustry.IsValidIndustry(src) || AIMap.DistanceManhattan(srcplace, AIIndustry.GetLocation(src)) > 1)) {
		LogWarning("Source industry was closed!");
		return false;
	}
	if (extra_dst != null) {
		if (!MyAIIndustry.IsValidIndustry(extra_dst) || AIMap.DistanceManhattan(passplace == null ? dstplace : passplace, AIIndustry.GetLocation(extra_dst)) > 1) {
			LogWarning("Destination industry was closed, transforming station into passing lane!");
			cBuilder.CloseRailPassingStation(stapass);
			extra_dst = null;
			extracrg = null;
			passplace = null;
		}
	}
	if (!dstistown && (!MyAIIndustry.IsValidIndustry(dst) || AIMap.DistanceManhattan(dstplace, AIIndustry.GetLocation(dst)) > 1)) {
		if (extra_dst != null) {
			if (segment == 0) {
				LogWarning("Destination industry was closed!");
				return false;
			}
			LogWarning("Passing destination industry was closed, transforming passing station to terminal!");
			local tile1 = passinglanelist.GetExit(passinglanelist.Count() - 1);
			if (!AITile.IsStationTile(tile1)) AITile.DemolishTile(tile1);
			local tile2 = passinglanelist.GetFrontExit(passinglanelist.Count() - 1);
			if (!AITile.IsStationTile(tile2)) AITile.DemolishTile(tile2);
			cBuilder.DeleteRailStation(stadst);
			dst = extra_dst;
			extra_dst = null;
			crg = extracrg;
			extracrg = null;
			if (passplace != null) dstplace = passplace;
			passplace = null;
			if (stapass != null) stadst = stapass;
			stapass = null;
			if (double_pass_station) {
				local tile3 = passinglanelist.GetBlockExit(passinglanelist.Count() - 1);
				if (tile3 != null) {
					local tilelist = AITileList();
					tilelist.AddRectangle(tile2, tile3);
					foreach (tile, dummy in tilelist) if (tile != tile1 && tile != tile2 && tile != tile3 && !AITile.IsStationTile(tile)) AITile.DemolishTile(tile);
				}
				trains--;
			}
		} else {
			LogWarning("Destination industry was closed!");
			return false;
		}
	}
	return true;
}
