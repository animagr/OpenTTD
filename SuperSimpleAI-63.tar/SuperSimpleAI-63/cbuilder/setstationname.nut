/**
 * This file is part of SuperSimpleAI: An OpenTTD AI.
 *
 * Based on code from SimpleAI, written by Brumi.
 *
 * Author: Jaume Sabater
 *
 * It's free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 2 of the License, or
 * any later version.
 *
 * You should have received a copy of the GNU General Public License
 * with it.  If not, see <http://www.gnu.org/licenses/>.
 */

/**
 * The new name of the station.
 * @param station_id The basestation to set the name of.
 * @param prefix Should be short, like "SRC", "DST" and "PAS".
 * @param routes Number of routes.
 * @return True if success.
 */
function cBuilder::SetStationName(station_id, prefix, routes)
{
	if (!AISettings.RenameStations()) return false;
	return MyStation.SetName(station_id, prefix, routes);
}

/**
 * The temporal name of the station under construction.
 * @param station_id The basestation to set the name of.
 * @param prefix Should be short, like "SRC", "DST" and "PAS".
 * @return True if success.
 */
function cBuilder::SetStationTmpName(station_id, prefix)
{
	if (!AISettings.RenameStations()) return false;
	return MyStation.SetName(station_id, prefix, root.buildcounter, ".tmp");
}
