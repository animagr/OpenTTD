/**
 * This file is part of SuperSimpleAI: An OpenTTD AI.
 *
 * Author: Jaume Sabater
 *
 * It's free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 2 of the License, or
 * any later version.
 *
 * You should have received a copy of the GNU General Public License
 * with it.  If not, see <http://www.gnu.org/licenses/>.
 */

/**
 * Load definition of cBuilder class.
 */
require("cbuilder.nut");

/**
 * cBuilder class definition is into builder.nut file,
 * load all builder functions after builder.nut file.
 */
require("air.nut");
require("areindustriesalive.nut");
require("buildsomething.nut");
require("extra.nut");
require("findservice.nut");
require("group.nut");
require("rail.nut");
require("rail-passinglanes.nut");
require("rail-stations.nut");
require("road.nut");
require("road-stations.nut");
require("route.nut");
require("setstationname.nut");
require("vehicles.nut");
require("waitformoney.nut");
