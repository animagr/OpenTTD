/**
 * This file is part of SuperSimpleAI: An OpenTTD AI.
 *
 * Based on code from SimpleAI, written by Brumi.
 *
 * Author: Jaume Sabater
 *
 * It's free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 2 of the License, or
 * any later version.
 *
 * You should have received a copy of the GNU General Public License
 * with it.  If not, see <http://www.gnu.org/licenses/>.
 */

class cManager
{
	root = null; // Reference to the main SuperSimpleAI instance.
	todepotlist = null; // A list of vehicles heading for the depot.
	eventqueue = null; // Used for loading the event queue from a savegame.
	lastlooprun = null; // Date when MainLoop() was used.
	lastloopruntime = null; // Time needed last loop.
	lastloopidx = null; // Last idx value of CheckRoutes().
	lastremovedunuseddepots = null; // Last date when checked all depots.

	// Antiflood
	lastmonthwarnairlimit = null; // Last month that a warning for reaching the aircraft limit was printed on console.
	lastmonthwarnroadlimit = null; // Last month that a warning for reaching the road vehicles limit was printed on console.
	lastmonthwarnraillimit = null; // Last month that a warning for reaching the trains limit was printed on console.

	constructor(that) {
		root = that;
		todepotlist = AIList();
		eventqueue = [];
		lastlooprun = 0;
		lastloopruntime = 1;
		lastloopidx = 0;
		lastmonthwarnairlimit = 0;
		lastmonthwarnroadlimit = 0;
		lastmonthwarnraillimit = 0;
		lastremovedunuseddepots = 0;
	}

	/**
	 * Main Loop that check events, ToDepotList and routes.
	 */
	static function MainLoop();

	/**
	 * Checks and handles events waiting in the event queue.
	 */
	static function CheckEvents();

	/**
	 * Checks all routes. Empty routes are removed, new vehicles are added if needed, old vehicles are replaced,
	 * vehicles are restarted if sitting in the depot for no reason, rails are electrified, short trains are lengthened.
	 */
	static function CheckRoutes();

	/**
	 * Adds a new vehicle to an existing route. All vehicle types are supported.
	 * @param route The route to which the new vehicle will be added.
	 * @param mainvehicle An already existing vehicle on the route to share orders with.
	 * @param engine The EngineID of the new vehicle. In case of trains it is the EngineID of the locomotive.
	 * @param wagon The EngineID of the train wagons. This parameter is unused in case of road vehicles and aircraft.
	 * @param renew Boolean parameter for renewing old vehicles.
	 * @return True if the action succeeded.
	 */
	static function AddVehicle(route, mainvehicle, engine, wagon, extra_wagon, renew);

	/**
	 * Replaces an old vehicle with a newer model if it is already in the depot.
	 * @param vehicle The vehicle to be replaced.
	 */
	static function ReplaceVehicle(vehicle);

	/**
	 * Checks ungrouped vehicles. Under normal conditions all vehicles should be grouped.
	 */
	static function CheckDefaultGroup();

	/**
	 * Check vehicles in the todepotlist if they're actually heading for a depot.
	 */
	static function CheckTodepotlist();

	/**
	 * Send a generic vehicle to depot.
	 * @param vehicle The vehicle to send to depot.
	 * @return True if was sended to depot.
	 */
	static function SendVehicleToDepot(vehicle);

	/**
	 * Send a train to depot.
	 * @param vehicle The vehicle to send to depot.
	 * @return True if train was sended to depot.
	 */
	static function SendTrainToDepot(vehicle);

	/**
	 * Send a road vehicle to depot.
	 * @param vehicle The vehicle to send to depot.
	 * @return True if road vehicle was sended to depot.
	 */
	static function SendRoadVehcToDepot(vehicle);

	/**
	 * Check if we can print to log in AI settings.
	 * @return True if we can write to log (default).
	 */
	static function PrintLog();

	/**
	 * Write to log all info messages from cManager class.
	 * This function is defined in log.nut file.
	 * @param string Text to write to log.
	 */
	static function LogInfo(string);

	/**
	 * Write to log all warning messages from cManager class.
	 * This function is defined in log.nut file.
	 * @param string Text to write to log.
	 */
	static function LogWarning(string);

	/**
	 * Write to log all error messages from cManager class.
	 * This function is defined in log.nut file.
	 * @param string Text to write to log.
	 */
	static function LogError(string);

	/**
	 * Check if we are in Debug mode..
	 * @return True if we are in Debug mode (default is false).
	 */
	static function Debug();

	/**
	 * Write to log all info messages from cManager class.
	 * This function is defined in log.nut file.
	 * @param string Text to write to log.
	 */
	static function LogDebug(string);

	/**
	 * Send all vehicles from a list to depot, for sell.
	 * @param list of vehicles to sell.
	 */
	static function SendAllVehiclesToSell(list);

	/**
	 * Return true if we can close unprofitable routes.
	 * @param aistart true if uses this function to enable electrified rails at starting of this AI (optional).
	 * @return True if we can close routes.
	 */
	static function CloseUnprofitableRoutes(aistart = false);

	/**
	 * Return true if we can electrify rails.
	 * @return True if we can electrify rails.
	 */
	static function CanElectrifyRails();

	/**
	 * Remove all unused rail depots.
	 */
	static function RemoveUnusedRailDepots();

	/**
	 * Return true if we can add more vehicles.
	 * @param num Current number of vehicles.
	 * @param max Maximum number of vehicles.
	 * @return True if we can do it.
	 */
	static function CanAddMoreVehicles(num, max);
}

function cManager::RemoveUnusedRailDepots()
{
	local year = AIDate.GetYear(AIDate.GetCurrentDate());
	if (year > lastremovedunuseddepots) {
		LogDebug("Searching unused depots...");
		local depotlist = MyAIDepotList_Rail();
		local count = 0;
		foreach (deptile, dummy in depotlist) {
			local fronttile = AIRail.GetRailDepotFrontTile(deptile);
			if (!MyAIRail.AreConnectedRailTiles(deptile, fronttile)) {
				cBuilder.WaitAndDemolish(deptile);
				count++;
			}
		}
		if (count) LogInfo("Removed " + count + " unused depots");
		lastremovedunuseddepots = year;
	}
}

function cManager::MainLoop()
{
	root.manager.CheckEvents();
	local date = AIDate.GetCurrentDate();
	if (date < lastlooprun || date - lastlooprun > MyMath.Min(AISettings.DaysBeforeRunManagerMainLoop() * lastloopruntime, AISettings.MaxDaysBeetwenCheckRoutesRun())) {
		//LogInfo("Running main Manager loop... (last loop date was " + lastlooprun + ", last loop time was " + lastloopruntime + " days, date = " + date + ")");
		lastlooprun = date;
		root.manager.CheckTodepotlist();
		root.manager.CheckRoutes();
		Banker.PayLoan();
		lastloopruntime = MyMath.Max(AIDate.GetCurrentDate() - date, 1);
	}
}

function cManager::CheckEvents()
{
	local event = null;
	local loadedevent = [];
	local isloaded = null;
	local eventtype = null;
	while (eventqueue.len() > 0 || AIEventController.IsEventWaiting()) {
		if (eventqueue.len() > 0) {
			// Load an event from a savegame
			loadedevent = eventqueue.pop();
			eventtype = loadedevent[0];
			isloaded = true;
		} else {
			// Load events if there are no more events from the savegame
			event = AIEventController.GetNextEvent();
			eventtype = event.GetEventType();
			isloaded = false;
		}
		switch (eventtype) {
			case AIEvent.ET_SUBSIDY_AWARDED:
				// Just produce some log output if the subsidy is awarded to our company
				event = AIEventSubsidyAwarded.Convert(event);
				local sub = event.GetSubsidyID();
				if (AICompany.IsMine(AISubsidy.GetAwardedTo(sub))) {
					local srcname = null, dstname = null;
					if (AISubsidy.GetSourceType(sub) == AISubsidy.SPT_TOWN) {
						srcname = AITown.GetName(AISubsidy.GetSourceIndex(sub));
					} else {
						srcname = AIIndustry.GetName(AISubsidy.GetSourceIndex(sub));
					}
					if (AISubsidy.GetDestinationType(sub) == AISubsidy.SPT_TOWN) {
						dstname = AITown.GetName(AISubsidy.GetDestinationIndex(sub));
					} else {
						dstname = AIIndustry.GetName(AISubsidy.GetDestinationIndex(sub));
					}

					local crgname = AICargo.GetCargoLabel(AISubsidy.GetCargoType(sub));
					SuperSimpleAI.LogNotice("I got the subsidy: " + crgname + " from " + srcname + " to " + dstname);
				}
				break;

			case AIEvent.ET_ENGINE_PREVIEW:
				// Accept the preview if possible
				event = AIEventEnginePreview.Convert(event);
				if (event.AcceptPreview()) SuperSimpleAI.LogNotice("New engine available for preview: " + event.GetName());
				break;

			case AIEvent.ET_ENGINE_AVAILABLE:
				break;

			case AIEvent.ET_COMPANY_NEW:
				// Welcome the new company
				event = AIEventCompanyNew.Convert(event);
				local company = event.GetCompanyID();
				SuperSimpleAI.LogNotice("Welcome " + AICompany.GetName(company));
				break;

			case AIEvent.ET_COMPANY_IN_TROUBLE:
				// Some more serious action is needed, currently it is only logged
				event = AIEventCompanyInTrouble.Convert(event);
				local company = event.GetCompanyID();
				if (AICompany.IsMine(company)) SuperSimpleAI.LogError("I'm in trouble, I don't know what to do!");
				break;

			case AIEvent.ET_VEHICLE_CRASHED:
				// Clone the crashed vehicle if it still exists
				local vehicle = null;
				if (isloaded) {
					vehicle = loadedevent[1];
				} else {
					event = AIEventVehicleCrashed.Convert(event);
					vehicle = event.GetVehicleID();
				}
				LogError("One of my vehicles has crashed.");
				// Remove it from the todepotlist if it's there. It might be another vehicle, but that's not a big problem
				if (todepotlist.HasItem(vehicle)) todepotlist.RemoveItem(vehicle);
				// Check if it still exists
				if (!AIVehicle.IsValidVehicle(vehicle)) break;
				// Check if it is still the same vehicle
				if (AIVehicle.GetState(vehicle) != AIVehicle.VS_CRASHED) break;
				local group = AIVehicle.GetGroupID(vehicle);
				if (!root.groups.HasItem(group)) break;
				local route = root.groups.GetValue(group);
				local newveh = AIVehicle.CloneVehicle(root.routes[route].homedepot, vehicle, true);
				if (AIVehicle.IsValidVehicle(newveh)) {
					AIVehicle.StartStopVehicle(newveh);
					LogInfo("Cloned the crashed vehicle.");
				}
				break;

			case AIEvent.ET_VEHICLE_LOST:
				// No action taken, only logged
				event = AIEventVehicleLost.Convert(event);
				local vehicle = event.GetVehicleID();
				LogError("" + AIVehicle.GetName(vehicle) + " is lost, I don't know what to do with that!");
				/* TODO: Handle it. */
				break;

			case AIEvent.ET_VEHICLE_UNPROFITABLE:
				break;

			case AIEvent.ET_VEHICLE_WAITING_IN_DEPOT:
				local vehicle = null;
				local vehiclename = null;
				if (isloaded) {
					vehicle = loadedevent[1];
				} else {
					event = AIEventVehicleWaitingInDepot.Convert(event);
					vehicle = event.GetVehicleID();
				}
				vehiclename = AIVehicle.GetName(vehicle);
				if (todepotlist.HasItem(vehicle)) {
					switch (todepotlist.GetValue(vehicle)) {
						case SuperSimpleAI.TD_SELL:
							// Sell a vehicle because it is old or unprofitable
							if (AIVehicle.GetVehicleType(vehicle) == AIVehicle.VT_RAIL) {
								AIVehicle.SellWagonChain(vehicle, 0);
							} else {
								AIVehicle.SellVehicle(vehicle);
							}
							todepotlist.RemoveItem(vehicle);
							LogInfo("Sold " + vehiclename + ".");
							break;
						case SuperSimpleAI.TD_SELL_WAGONS:
						case SuperSimpleAI.TD_REPLACE:
							// Replace an old vehicle with a newer model
							if (cManager.ReplaceVehicle(vehicle)) LogInfo("Replaced " + vehiclename + ".");
							else LogInfo("Can not replace " + vehiclename + ", restarting it.");
							break;
						case SuperSimpleAI.TD_ATTACH_WAGONS:
							// Attach more wagons to an existing train, if we didn't have enough money to buy all wagons beforehand
							cBuilder.AttachMoreWagons(vehicle);
							AIVehicle.StartStopVehicle(vehicle);
							todepotlist.RemoveItem(vehicle);
							break;
					}
				} else {
					// The vehicle is not in todepotlist
					if (!AIVehicle.IsStoppedInDepot) {
						LogError("I don't know why " + vehiclename + " was sent to the depot, restarting it...");
						AIVehicle.StartStopVehicle(vehicle);
					}
				}
				break;

			case AIEvent.ET_INDUSTRY_OPEN:
				break;

			case AIEvent.ET_INDUSTRY_CLOSE:
				break;

			case AIEvent.ET_TOWN_FOUNDED:
				break;
		}
	}
}

function cManager::CheckRoutes()
{
	local reserved_cash = 0;
	local routesactive = root.routes.len();
	local railtype = AIRail.GetCurrentRailType();
	local loopcount = 0;
	local loopfinished = true;
	local loopmaxcount = MyMath.Max(40, (routesactive / 20).tointeger());
	local buildedstatue = false;
	//LogInfo("Starting cManager::CheckRoutes() with routes = " + root.routes.len() + " and engineblacklist = " + root.engineblacklist.Count());
	foreach (idx, route in root.routes) {
		if (idx < lastloopidx) continue;
		idx++;
		if (loopcount > loopmaxcount) {
			AIRail.SetCurrentRailType(railtype);
			loopfinished = false;
			break;
		}
		local NearestTown = AIStation.GetNearestTown(route.stasrc);
		local vehicles = AIVehicleList_Group(route.group);
		local vehiclescount = vehicles.Count();
		local SymetricRoute = MyAICargo.IsPassengersCargo(route.crg) || MyAICargo.IsMailCargo(route.crg);
		local groupname = AICargo.GetCargoLabel(route.crg) + " - " + AIStation.GetName(route.stasrc) + " - " + AIStation.GetName(route.stadst);
		local vehicletype = route.vehtype == 0 ? "trains" : (route.vehtype == 1 ? "road vehicles" : "airplanes");
		// Check orders
		if (vehiclescount > 0) {
			if (root.buildingstage == root.BS_NOTHING) {
				local vehicle = vehicles.Begin();
				if (AIOrder.GetOrderCount(vehicle) < 2) {
					LogError("Route " + groupname + " has " + AIOrder.GetOrderCount(vehicle) + " orders!");
					SendAllVehiclesToSell(vehicles);
				}
			}
			switch (route.vehtype) {
				case AIVehicle.VT_ROAD:

					/* Industry Closes */
					if (MyAICargo.IsFreightCargo(route.crg)) {
						if ((AICargo.GetTownEffect(route.crg) == AICargo.TE_NONE || AICargo.GetTownEffect(route.crg) == AICargo.TE_WATER) && !cBuilder.IsIndustryConnectedToDestinationStation(route.dst, route.stadst)) {
							if (route.maxvehicles > 0) {
								route.maxvehicles = 0;
								LogWarning("Destination industry near " + AIStation.GetName(route.stadst) + " was closed!");
							}
							SendAllVehiclesToSell(vehicles);
						}
						if (!SymetricRoute && (route.maxvehicles == 0 || !cBuilder.IsIndustryConnectedToSourceStation(route.src, route.stasrc))) {
							if (route.maxvehicles > 0) {
								route.maxvehicles = 0;
								LogWarning("Source industry near " + AIStation.GetName(route.stasrc) + " was closed!");
							}
							foreach (vehicle, dummy in vehicles) {
								if (todepotlist.HasItem(vehicle)) continue;
								if (AIVehicle.GetCargoLoad(vehicle, route.crg) > 0) {
									if (AIVehicle.GetState(vehicle) == AIVehicle.VS_AT_STATION) {
										AIController.Sleep(150);
										if (AIOrder.SkipToOrder(vehicle, 1)) LogInfo(AIVehicle.GetName(vehicle) + " is sending to destination because isn't empty");
									}
									continue;
								}
								if (!SendRoadVehcToDepot(vehicle)) continue;
								todepotlist.AddItem(vehicle, SuperSimpleAI.TD_SELL);
								LogInfo(AIVehicle.GetName(vehicle) + " is sending it to the depot because the route was closed");
							}
						}
					}

					/* Close non-profitable routes */
					if (CloseUnprofitableRoutes()) {
						local vehicles_age = AIList();
						vehicles_age.AddList(vehicles);
						vehicles_age.Valuate(AIVehicle.GetAge);
						vehicles_age.RemoveBelowValue(1200);
						if (vehiclescount > (route.maxvehicles / 10).tointeger() && vehicles_age.Count() > 2) {
							local LastYearProfit = MyAIGroup.GetProfitLastYear(route.group);
							SuperSimpleAI.LogNotice("Route " + idx + " near " + AITown.GetName(NearestTown) + " has " + vehiclescount + " " + vehicletype + " and last year profit was " + LastYearProfit);
							if (MyAIGroup.GetProfitThisYear(route.group) + LastYearProfit < 1200) {
								if (route.maxvehicles > 0 ) LogWarning("Group " + groupname + " has not profit! Clossing this route!");
								route.maxvehicles = 0;
								local vehicles_sell = AIVehicleList_Group(route.group);
								foreach (vehicle, dummy in vehicles_sell) {
									if (todepotlist.HasItem(vehicle)) continue;
									if (!MyAICargo.IsMailCargo(route.crg) && AIVehicle.GetCargoLoad(vehicle, route.crg) > 0) {
										if (AIVehicle.GetState(vehicle) == AIVehicle.VS_AT_STATION) {
											AIController.Sleep(150);
											if (AIOrder.SkipToOrder(vehicle, 1)) LogInfo(AIVehicle.GetName(vehicle) + " is sending to destination because isn't empty");
										}
										continue;
									}
									if (!SendRoadVehcToDepot(vehicle)) continue;
									LogInfo(AIVehicle.GetName(vehicle) + " is sending it to the depot because the route was closed");
									todepotlist.AddItem(vehicle, SuperSimpleAI.TD_SELL);
								}
							}
						}
					}


					// Choose a new model
					local engine = null;
					if (route.last_date < AIDate.GetCurrentDate() - 90) {
						engine = MyRoadVehs.ChooseRoadVeh(route.crg);
						route.last_engine = engine;
						route.last_date = AIDate.GetCurrentDate();
					} else {
						engine = route.last_engine;
					}

					if (engine != null) {
						local vehicle_cost = Banker.GetMinimumCashNeeded() + AIEngine.GetPrice(engine);

						/* Adding vehicles */
						if (CanAddMoreVehicles(vehiclescount, route.maxvehicles) && (
								   (AIStation.GetCargoWaiting(route.stasrc, route.crg) > 100)
								|| (SymetricRoute && AIStation.GetCargoWaiting(route.stadst, route.crg) > 100)
						)) {
							// Only add new vehicles if the newest one is at least 20 days old
							vehicles.Valuate(AIVehicle.GetAge);
							vehicles.Sort(AIList.SORT_BY_VALUE, false);
							local new_route_age = vehicles.GetValue(vehicles.Begin());
							vehicles.Sort(AIList.SORT_BY_VALUE, true);
							if (vehicles.GetValue(vehicles.Begin()) > (new_route_age < 360 ? 10 : 20)) {
								if (Banker.GetMaxBankBalance() > (reserved_cash + vehicle_cost)) {
									if (cManager.AddVehicle(route, vehicles.Begin(), engine, null, null, false)) {
										LogInfo("Added road vehicle " + (vehiclescount + 1) + " to route: " + groupname);
									}
								}
							}
						}

						/* Replacing old vehicles */
						local vehicles_old = AIList();
						vehicles_old.AddList(vehicles);
						vehicles_old.Valuate(AIVehicle.GetAgeLeft);
						vehicles_old.KeepBelowValue(180);
						foreach (vehicle, dummy in vehicles_old) {
							if (todepotlist.HasItem(vehicle)) continue;
							if (AIVehicle.GetAge(vehicle) < 14600 && !SymetricRoute && AIVehicle.GetCargoLoad(vehicle,route.crg) > 0) continue;
							if (AIOrder.ResolveOrderPosition(vehicle, AIOrder.ORDER_CURRENT) != 0) continue;
							// Replace it only if we can afford it
							if (Banker.GetMaxBankBalance() > (reserved_cash + vehicle_cost)) {
								if (!SendRoadVehcToDepot(vehicle)) continue;
								LogInfo(AIVehicle.GetName(vehicle) + " is getting old, sending it to the depot...");
								reserved_cash = reserved_cash + vehicle_cost;
								todepotlist.AddItem(vehicle, SuperSimpleAI.TD_REPLACE);
							}
						}
					}

					/* Checking vehicles in depot */
					if (root.buildingstage == root.BS_NOTHING) {
						vehicles.Valuate(AIVehicle.IsStoppedInDepot);
						vehicles.KeepValue(1);
						foreach (vehicle, dummy in vehicles) {
							// A vehicle has probably been sitting there for ages if its current year/last year profits are both 0, and it's at least 12 months old
							if (AIVehicle.GetProfitThisYear(vehicle) != 0 || AIVehicle.GetProfitLastYear(vehicle) != 0 || AIVehicle.GetAge(vehicle) < 360) continue;
							if (todepotlist.HasItem(vehicle)) {
								todepotlist.RemoveItem(vehicle);
								AIVehicle.StartStopVehicle(vehicle);
							} else {
								// Sell it if we have no idea how it got there
								LogWarning("Sold " + AIVehicle.GetName(vehicle) + ", as it has been sitting in the depot for ages.");
								AIVehicle.SellVehicle(vehicle);
							}
						}
					}

				break;

				case AIVehicle.VT_RAIL:
					local platform = cBuilder.GetRailRoutePlatformLength(route.stasrc, route.stadst, route.stapas);
					if (MyAICargo.IsFreightCargo(route.crg)) {

						/* Industry Closes */
						if (route.pas != null) {
							local to_sell = 0;
							local tmpcrg = route.extracrg == null ? route.pas : route.extracrg;
							if ((AICargo.GetTownEffect(tmpcrg) == AICargo.TE_NONE || AICargo.GetTownEffect(tmpcrg) == AICargo.TE_WATER) && !cBuilder.IsIndustryConnectedToDestinationStation(route.pas, route.stapas)) {
								if (AIOrder.GetOrderCount(vehicles.Begin()) == 3) {
									LogWarning("Destination industry near " + AIStation.GetName(route.stapas) + " was closed!");
									AIOrder.RemoveOrder(vehicles.Begin(), 1);
									// Temporaly used...
									route.pas = route.extracrg;
									route.extracrg = null;
								}
								if (route.stapas != null) {
									local staname = AIStation.GetName(route.stapas);
									if (staname != null) LogInfo("Trying to close station near " + staname);
									cBuilder.CloseRailPassingStation(route.stapas);
									if (staname == null || cBuilder.CloseRailPassingStation(route.stapas)) route.stapas = null;
								}
								foreach (vehicle, dummy in vehicles) {
									if (todepotlist.HasItem(vehicle)) continue;
									if (AIVehicle.GetCapacity(vehicle, route.pas) > 0) {
										to_sell++;
										if (AIVehicle.GetCargoLoad(vehicle, route.crg) == 0) {
											AIController.Sleep(150);
											if (!SendTrainToDepot(vehicle)) continue;
											todepotlist.AddItem(vehicle, SuperSimpleAI.TD_SELL_WAGONS);
											LogInfo(AIVehicle.GetName(vehicle) + " is sending it to the depot because changes on acceptance cargos!");
										}
									}
								}
								if (to_sell == 0 && route.stapas == null) {
									route.pas = null;
									LogInfo("Passing station of route " + idx + " was successfully closed!");
								}
							}
							// Provisional, repe
							if ((AICargo.GetTownEffect(route.crg) == AICargo.TE_NONE || AICargo.GetTownEffect(route.crg) == AICargo.TE_WATER) && !cBuilder.IsIndustryConnectedToDestinationStation(route.dst, route.stadst)) {
								if (route.maxvehicles > 0) {
									route.maxvehicles = 0;
									LogWarning("Destination industry near " + AIStation.GetName(route.stadst) + " was closed!");
								}
								SendAllVehiclesToSell(vehicles);
							}
						} else {
							if ((AICargo.GetTownEffect(route.crg) == AICargo.TE_NONE || AICargo.GetTownEffect(route.crg) == AICargo.TE_WATER) && !cBuilder.IsIndustryConnectedToDestinationStation(route.dst, route.stadst)) {
								if (route.maxvehicles > 0) {
									route.maxvehicles = 0;
									LogWarning("Destination industry near " + AIStation.GetName(route.stadst) + " was closed!");
								}
								SendAllVehiclesToSell(vehicles);
							}
						}
						if (route.maxvehicles == 0 || !cBuilder.IsIndustryConnectedToSourceStation(route.src, route.stasrc)) {
							if (route.maxvehicles > 0) {
								route.maxvehicles = 0;
								LogWarning("Source industry near " + AIStation.GetName(route.stasrc) + " was closed!");
							}
							foreach (vehicle, dummy in vehicles) {
								if (todepotlist.HasItem(vehicle)) continue;
								if (!SymetricRoute && AIVehicle.GetCargoLoad(vehicle, route.crg) > AIVehicle.GetCapacity(vehicle, route.crg)/2) {
									if (AIVehicle.GetState(vehicle) == AIVehicle.VS_AT_STATION) {
										AIController.Sleep(150);
										if (AIOrder.SkipToOrder(vehicle, 1)) LogInfo(AIVehicle.GetName(vehicle) + " is sending to destination because isn't empty");
									}
									continue;
								}
								if (!SendTrainToDepot(vehicle)) continue;
								todepotlist.AddItem(vehicle, SuperSimpleAI.TD_SELL);
								LogInfo(AIVehicle.GetName(vehicle) + " is sending it to the depot because the route was closed");
							}
						}
					}

					/* Close non-profitable routes */
					if (CloseUnprofitableRoutes()) {
						local vehicles_age = AIList();
						vehicles_age.AddList(vehicles);
						vehicles_age.Valuate(AIVehicle.GetAge);
						vehicles_age.RemoveBelowValue(2400);
						if (vehiclescount > (route.maxvehicles / 3).tointeger() && vehicles_age.Count() > 1) {
							local Last22MonthsProfit = MyAIGroup.GetProfitLastYear(route.group) + MyAIGroup.GetProfitThisYear(route.group) - (route.stapas != null ? 3600 : 2400);
							SuperSimpleAI.LogNotice("Route " + idx + " near " + AITown.GetName(NearestTown) + " has " + vehiclescount + " " + vehicletype + " and last 22 months profit was " + Last22MonthsProfit);
							if (Last22MonthsProfit < 0) {
								if (route.maxvehicles > 0 ) LogWarning("Group " + groupname + " has not profit! Clossing this route!");
								route.maxvehicles = 0;
								local vehicles_sell = AIVehicleList_Group(route.group);
								foreach (vehicle, dummy in vehicles_sell) {
									if (todepotlist.HasItem(vehicle)) continue;
									if (!MyAICargo.IsMailCargo(route.crg) && AIVehicle.GetCargoLoad(vehicle,route.crg) > AIVehicle.GetCapacity(vehicle, route.crg)/2) {
										if (AIVehicle.GetState(vehicle) == AIVehicle.VS_AT_STATION) {
											AIController.Sleep(150);
											if (AIOrder.SkipToOrder(vehicle, 1)) LogInfo(AIVehicle.GetName(vehicle) + " is sending to destination because isn't empty");
										}
										continue;
									}
									if (!SendTrainToDepot(vehicle)) continue;
									LogInfo(AIVehicle.GetName(vehicle) + " is sending it to the depot because the route was closed");
									todepotlist.AddItem(vehicle, SuperSimpleAI.TD_SELL);
								}
							}
						}
					}

					/* Electrifying rails */
					if (CanElectrifyRails()) {
						if (routesactive > 20 && (AISettings.ElectrifyOldRailLines() == 3 || (AISettings.ElectrifyOldRailLines() == 2 && vehiclescount == route.maxvehicles) || (AISettings.ElectrifyOldRailLines() == 1 && AICargo.HasCargoClass(route.crg, AICargo.CC_PASSENGERS))) && AIRail.TrainHasPowerOnRail(route.railtype, AIRail.GetCurrentRailType()) && route.railtype != AIRail.GetCurrentRailType()) {
							vehicles.Valuate(AIVehicle.GetAgeLeft);
							vehicles.Sort(AIList.SORT_BY_VALUE, true);
							if (vehicles.GetValue(vehicles.Begin()) < 1460) {
							// Check if we can afford it
								if (MyAICompany.GetMyBankBalance() < reserved_cash + AISettings.MinMoneyToElectrify()) {
									Banker.SetMinimumBankBalance(AISettings.MinMoneyToElectrify());
								}
								LogInfo("Electrifying rail line: " + groupname);
								// A builder instance is needed to call ElectrifyRail
								local builder = cBuilder(root);
								if (builder.ElectrifyRail(AIStation.GetLocation(route.stasrc))) {
									LogDebug("Rail line successfully electrifyed: " + groupname);
									route.railtype = AIRail.GetCurrentRailType();
								}
								builder = null;
							}
						}
					}

					// Choose a new model
					AIRail.SetCurrentRailType(route.railtype);
					local wagon = null;
					local extra_wagon = null;
					local engine = null;
					if (route.last_date < AIDate.GetCurrentDate() - 90) {
						wagon = MyTrains.ChooseWagon(route.crg, root.engineblacklist);
						extra_wagon = (route.extracrg == null) ? null : MyTrains.ChooseWagon(route.extracrg, root.engineblacklist);
						local wagonminspeed = wagon;
						local wagoncrg = route.crg;
						if (extra_wagon!= null) {
							if (AIEngine.GetMaxSpeed(wagon) > AIEngine.GetMaxSpeed(extra_wagon)) {
								wagonminspeed = extra_wagon;
								wagoncrg = route.extracrg;
							}
						}
						engine = MyTrains.ChooseTrainEngine(wagoncrg, AIMap.DistanceManhattan(AIStation.GetLocation(route.stasrc), AIStation.GetLocation(route.stadst)), wagonminspeed, platform * 2 - 1, root.engineblacklist);
						route.last_wagon = wagon;
						route.last_extra_wagon = extra_wagon;
						route.last_engine = engine;
						route.last_date = AIDate.GetCurrentDate();
					} else {
						wagon = route.last_wagon;
						extra_wagon = route.last_extra_wagon;
						engine = route.last_engine;
					}
					if (wagon != null && engine != null) {
						local engine_count = cBuilder.GetNumEnginesNeeded(engine, route.homedepot, platform * 2 - 1, route.slopes, wagon, route.crg, extra_wagon, route.extracrg);
						local vehicle_cost = Banker.GetMinimumCashNeeded() + AIEngine.GetPrice(engine) * engine_count + (platform * 2 - 1) * AIEngine.GetPrice(wagon);
						//local blacklistcount = root.engineblacklist.Count();
						if (cBuilder.IsEngineCompatibleWithWagon(route.homedepot, engine, wagon, root.engineblacklist) && (extra_wagon == null || cBuilder.IsEngineCompatibleWithWagon(route.homedepot, engine, extra_wagon, root.engineblacklist))) {
							//LogInfo("countloops = " + idx + "    last = " + blacklistcount + "    engineblacklist = " + root.engineblacklist.Count());
							local maxbankbalance = Banker.GetMaxBankBalance();
							if (maxbankbalance > vehicle_cost) {

								/* Adding trains */
								if (CanAddMoreVehicles(vehiclescount, route.maxvehicles) && root.routes_active > 3 && (root.buildcounter > 15 || maxbankbalance > reserved_cash + Banker.InflatedValue(500000)) && (
								   (maxbankbalance > reserved_cash + Banker.InflatedValue(300000) && (AIStation.GetCargoRating(route.stasrc, route.crg) < 60)
									|| (AITown.HasStatue(NearestTown) && AIStation.GetCargoRating(route.stasrc, route.crg) < 70))
									|| (vehiclescount == 1 && (route.maxvehicles > 3 || MyAICargo.IsPassengersCargo(route.crg)))
								 	|| ((maxbankbalance > reserved_cash + Banker.InflatedValue(320000) || root.buildcounter > 20) && vehiclescount == 2 && route.maxvehicles > 6)
								 	|| ((maxbankbalance > reserved_cash + Banker.InflatedValue(330000) || root.buildcounter > 25) && vehiclescount == 2 && route.maxvehicles > 5)
								 	|| ((maxbankbalance > reserved_cash + Banker.InflatedValue(340000) || root.buildcounter > 30) && vehiclescount == 2 && route.maxvehicles > 4)
								 	|| ((maxbankbalance > reserved_cash + Banker.InflatedValue(350000) || root.buildcounter > 35) && vehiclescount == 3 && route.maxvehicles > 11)
								 	|| ((maxbankbalance > reserved_cash + Banker.InflatedValue(360000) || root.buildcounter > 40) && vehiclescount == 3 && route.maxvehicles > 10)
						 			|| ((maxbankbalance > reserved_cash + Banker.InflatedValue(370000) || root.buildcounter > 45) && vehiclescount == 3 && route.maxvehicles > 9)
								 	|| ((maxbankbalance > reserved_cash + Banker.InflatedValue(380000) || root.buildcounter > 50) && vehiclescount == 3 && route.maxvehicles > 8)
								 	|| ((maxbankbalance > reserved_cash + Banker.InflatedValue(390000) || root.buildcounter > 55) && vehiclescount == 1 && route.maxvehicles == 2)
								)) {
       			               		                	// Only add new vehicles if the newest one is at least 30 days old and latest vehicle added is half-loaded
									local vehicles_add = AIList();
									vehicles_add.AddList(vehicles);
									vehicles_add.Valuate(AIVehicle.GetAge);
									vehicles_add.Sort(AIList.SORT_BY_VALUE, true);
									if (vehicles_add.GetValue(vehicles_add.Begin()) > 30 && ( AIVehicle.GetCargoLoad(vehicles_add.Begin(),route.crg) > AIVehicle.GetCapacity(vehicles_add.Begin(), route.crg)/2 || ( AIVehicle.GetState(vehicles_add.Begin()) != AIVehicle.VS_AT_STATION && AIVehicle.GetState(vehicles_add.Begin()) != AIVehicle.VS_IN_DEPOT))) {
										// Check if we can afford it
										if (Banker.GetMaxBankBalance() > (reserved_cash + vehicle_cost)) {
											if (MyAICompany.GetMyBankBalance() < reserved_cash + vehicle_cost) {
												Banker.SetMinimumBankBalance(vehicle_cost);
											}
											if (cManager.AddVehicle(route, vehicles_add.Begin(), engine, wagon, extra_wagon, false)) {
												LogInfo("Added train " + (vehiclescount + 1) + " to route: " + groupname);
											}
										}
									}
								}

								/* Replacing old vehicles */
								local vehicles_old = AIList();
								vehicles_old.AddList(vehicles);
								vehicles_old.Valuate(AIVehicle.GetAgeLeft);
								vehicles_old.KeepBelowValue(360);
								foreach (vehicle, dummy in vehicles_old) {
									local vehicle_is_old = AIVehicle.GetAge(vehicle) < 29200;
									if (vehicle_is_old && !SymetricRoute && AIVehicle.GetCargoLoad(vehicle, route.crg) > 0) continue;
									if (vehicle_is_old && route.extracrg != null && AIVehicle.GetCargoLoad(vehicle, route.extracrg) > 0) continue;
									if (todepotlist.HasItem(vehicle)) continue;
									if (AIOrder.ResolveOrderPosition(vehicle, AIOrder.ORDER_CURRENT) != 0) continue;
									// Replace it only if we can afford it
									if (Banker.GetMaxBankBalance() > (reserved_cash + vehicle_cost)) {
										if (SendTrainToDepot(vehicle)) {
											todepotlist.AddItem(vehicle, SuperSimpleAI.TD_REPLACE);
											reserved_cash = reserved_cash + vehicle_cost;
											LogInfo(AIVehicle.GetName(vehicle) + " is getting old, sending it to the depot...");
										}
									}
								}
							}

							/* Lengthening short trains */
							local max_platform_len = platform * 16 - 7;
							if (wagon != null) {
								foreach (train, dummy in vehicles) {
									// The train should fill its platform
									if (AIVehicle.GetLength(train) < max_platform_len) {
										if (todepotlist.HasItem(train)) continue;
										if (AIOrder.ResolveOrderPosition(train, AIOrder.ORDER_CURRENT) != 0) continue;
										if (!SymetricRoute && AIVehicle.GetCargoLoad(train, route.crg) > 0) continue;
										if (route.extracrg != null && AIVehicle.GetCargoLoad(train, route.extracrg) > 0) continue;
										// Check if we can afford it
										vehicle_cost = Banker.GetMinimumCashNeeded() + 2 * cBuilder.GetTrainMaxLength(route.crg) * AIEngine.GetPrice(wagon);
										if (Banker.GetMaxBankBalance() > (reserved_cash + vehicle_cost)) {
											if (SendTrainToDepot(train)) {
												todepotlist.AddItem(train, SuperSimpleAI.TD_ATTACH_WAGONS);
												reserved_cash = reserved_cash + vehicle_cost;
												LogInfo(AIVehicle.GetName(train) + " is short, sending it to the depot to attach more wagons...");
											}
										}
									}
								}
							}
						}
					}

					/* Checking vehicles in depot */
					if (root.buildingstage == root.BS_NOTHING) {
						vehicles.Valuate(AIVehicle.IsStoppedInDepot);
						vehicles.KeepValue(1);
						foreach (vehicle, dummy in vehicles) {
							// A vehicle has probably been sitting there for ages if its current year/last year profits are both 0, and it's at least 12 months old
							if (AIVehicle.GetProfitThisYear(vehicle) != 0 || AIVehicle.GetProfitLastYear(vehicle) != 0 || AIVehicle.GetAge(vehicle) < 360) continue;
							if (todepotlist.HasItem(vehicle)) {
								todepotlist.RemoveItem(vehicle);
								AIVehicle.StartStopVehicle(vehicle);
							} else {
								// Sell it if we have no idea how it got there
								LogWarning("Sold " + AIVehicle.GetName(vehicle) + ", as it has been sitting in the depot for ages.");
								AIVehicle.SellWagonChain(vehicle, 0);
							}
						}
					}

				break;

				case AIVehicle.VT_AIR:
					local srctype = AIAirport.GetAirportType(AIStation.GetLocation(route.stasrc));
					local dsttype = AIAirport.GetAirportType(AIStation.GetLocation(route.stadst));
					local is_small = MyAIAirport.IsSmallAirport(srctype) || MyAIAirport.IsSmallAirport(dsttype);

					// Choose a new model
					local engine = null;
					if (route.last_date < AIDate.GetCurrentDate() - 90) {
						engine = MyPlanes.ChoosePlane(route.crg, is_small, AIOrder.GetOrderDistance(AIVehicle.VT_AIR, AIStation.GetLocation(route.stasrc), AIStation.GetLocation(route.stadst)), false);
						route.last_engine = engine;
						route.last_date = AIDate.GetCurrentDate();
					} else {
						engine = route.last_engine;
					}

					if (engine != null) {
						local vehicle_cost = Banker.GetMinimumCashNeeded() + AIEngine.GetPrice(engine);

						/* Adding vehicles */
						local canaddplane = true;
						local dist = AIMap.DistanceManhattan(AIStation.GetLocation(route.stasrc), AIStation.GetLocation(route.stadst));
						local max_airplanes = cBuilder.GetMaxAirplanes(dist);
						if (2 * AISettings.GetAirportTypeCapacity(srctype) < max_airplanes + AIVehicleList_Station(route.stasrc).Count()) canaddplane = false;
						if (2 * AISettings.GetAirportTypeCapacity(dsttype) < max_airplanes + AIVehicleList_Station(route.stadst).Count()) canaddplane = false;
						// Only add planes if there is some free capacity at both airports
						if (canaddplane && CanAddMoreVehicles(vehiclescount, max_airplanes) && (AIStation.GetCargoWaiting(route.stasrc, route.crg) > 300 || AIStation.GetCargoWaiting(route.stadst, route.crg) > 300)) {
							// Do not add new planes if there are unprofitable ones
							vehicles.Valuate(AIVehicle.GetProfitThisYear);
							if (vehicles.GetValue(vehicles.Begin()) <= 0) break;
							// Only add new planes if the newest one is at least 4 months old
							vehicles.Valuate(AIVehicle.GetAge);
							vehicles.Sort(AIList.SORT_BY_VALUE, true);
							if (vehicles.GetValue(vehicles.Begin()) > 120) {
								// Check if we can afford it
								if (Banker.GetMaxBankBalance() > (reserved_cash + vehicle_cost)) {
									if (cManager.AddVehicle(route, vehicles.Begin(), engine, null, null, false)) {
										LogInfo("Added plane " + (vehiclescount + 1) + " to route: " + groupname);
									}
								}
							}
						}

						/* Replacing old vehicles */
						local vehicles_old = AIList();
						vehicles_old.AddList(vehicles);
						vehicles_old.Valuate(AIVehicle.GetAgeLeft);
						vehicles_old.KeepBelowValue(180);
						foreach (vehicle, dummy in vehicles_old) {
							if (todepotlist.HasItem(vehicle)) continue;
							// Check if we can afford it
							if (Banker.GetMaxBankBalance() > (reserved_cash + vehicle_cost)) {
								if (!AIVehicle.SendVehicleToDepot(vehicle)) continue;
								LogInfo(AIVehicle.GetName(vehicle) + " is getting old, sending it to the hangar...");
								reserved_cash = reserved_cash + vehicle_cost;
								todepotlist.AddItem(vehicle, SuperSimpleAI.TD_REPLACE);
							}
						}
					}

					/* Checking vehicles in depot */
					vehicles.Valuate(AIVehicle.IsStoppedInDepot);
					vehicles.KeepValue(1);
					foreach (vehicle, dummy in vehicles) {
						// A vehicle has probably been sitting there for ages if its current year/last year profits are both 0, and it's at least 2 months old
						if (AIVehicle.GetProfitThisYear(vehicle) != 0 || AIVehicle.GetProfitLastYear(vehicle) != 0 || AIVehicle.GetAge(vehicle) < 60) continue;
						if (todepotlist.HasItem(vehicle)) {
							todepotlist.RemoveItem(vehicle);
							AIVehicle.StartStopVehicle(vehicle);
						} else {
							// Sell it if we have no idea how it got there
							AIVehicle.SellVehicle(vehicle);
							LogWarning("Sold " + AIVehicle.GetName(vehicle) + ", as it has been sitting in the depot for ages.");
						}
					}
				break;
			}

			if (!buildedstatue) {
				/* Building statue */
				if (!AITown.HasStatue(NearestTown) && root.routes_active > 12 && AISettings.CanBuildStatue() && Banker.GetMaxBankBalance() > reserved_cash + AISettings.MiniumMoneyToBuildStatue()) {
					if (AITown.PerformTownAction(NearestTown, AITown.TOWN_ACTION_BUILD_STATUE)) {
						SuperSimpleAI.LogNotice("Building a statue at " + AITown.GetName(NearestTown));
						buildedstatue = true;
					}
				}
				if (SymetricRoute) {
					local OtherTown = AIStation.GetNearestTown(route.stadst);
					if (!AITown.HasStatue(OtherTown) && root.routes_active > 12 && AISettings.CanBuildStatue() && Banker.GetMaxBankBalance() > reserved_cash + AISettings.MiniumMoneyToBuildStatue()) {
						if (AITown.PerformTownAction(OtherTown, AITown.TOWN_ACTION_BUILD_STATUE)) {
							SuperSimpleAI.LogNotice("Building a statue at " + AITown.GetName(OtherTown));
							buildedstatue = true;
						}
					}
				}
			}

			// Check events here insted of do it in MainLoop() function.
			root.manager.CheckEvents();
		} else {
			/* Empty route */
			if (route.vehtype != null && root.buildingstage == root.BS_NOTHING) {
				LogInfo("Removing empty route: " + groupname);
				root.groups.RemoveItem(route.group);
				root.groups_array = MyAIList.ListToArray(root.groups);
				AIGroup.DeleteGroup(route.group);
				root.serviced.RemoveItem(route.src * 256 + route.crg);
				if (MyAICargo.IsPassengersCargo(route.crg)) root.serviced.RemoveItem(route.dst * 256 + route.crg);
				root.serviced_array = MyAIList.ListToArray(root.serviced);
				if (route.vehtype == AIVehicle.VT_ROAD) {
					cBuilder.DeleteRoadStation(route.stasrc);
					cBuilder.DeleteRoadStation(route.stadst);
				}
				if (route.vehtype == AIVehicle.VT_RAIL) {
					local builder = cBuilder(root);
					// Connected rails will automatically be removed
					builder.DeleteRailStation(route.stasrc);
					builder.DeleteRailStation(route.stadst);
					builder = null;
				}
				if (route.vehtype == AIVehicle.VT_AIR) {
					// DeleteAirport will only delete the airports if they are unused
					cBuilder.DeleteAirport(route.stasrc);
					cBuilder.DeleteAirport(route.stadst);
				}
				route.vehtype = null;
				root.routes_active--;
			}
		}
		lastloopidx = idx;
		loopcount++;
	}
	if (loopfinished) lastloopidx = 0;

	// Check ugrouped vehicles as well. There should be none after all...
	cManager.CheckDefaultGroup();
	AIRail.SetCurrentRailType(railtype);
}

function cManager::CloseUnprofitableRoutes()
{
	if (!AISettings.CloseUnprofitableRoutes()) return false;
	local date = AIDate.GetCurrentDate();
	local month = AIDate.GetMonth(date);
	return root.routes_active > 15 && (month == 11 || (month == 12 && AIDate.GetDayOfMonth(date) < 28));
}

function cManager::CanElectrifyRails(aistart = false)
{
	if ((root.buildingstage == root.BS_NOTHING && Banker.GetMaxBankBalance() > AISettings.MinMoneyToElectrify() + AICompany.GetMaxLoanAmount() && root.routes_active > AISettings.MinRoutesToBuildElectrifiedRail()) || aistart) {
		if (!root.el_rails) {
			root.el_rails = true;
			SuperSimpleAI.LogNotice("Enabling electrified rails");
		}
		return true;
	}
	return false;
}

function cManager::CanAddMoreVehicles(num, max)
{
	return (num != 0 && num < max);
}

function cManager::AddVehicle(route, mainvehicle, engine, wagon, extra_wagon, renew)
{
	// A builder instance is needed to add a new vehicle
	local builder = cBuilder(root);
	local success = true;
	local reserved_vehicles = renew ? 1 : 2;
	builder.crg = route.crg;
	builder.extracrg = route.extracrg;
	builder.stasrc = route.stasrc;
	builder.stapass = route.stapas;
	builder.stadst = route.stadst;
	builder.group = route.group;
	builder.slopes = route.slopes;
	builder.homedepot = route.homedepot;
	switch (route.vehtype) {
		case AIVehicle.VT_RAIL:
			local prod1_percent = MyAIIndustry.GetProductionPercentage(route.src, route.crg, route.extracrg);
			local trains = MyAIVehicleList_Trains();
			// Do not try to add one if we have already reached the train limit
			if (trains.Count() + reserved_vehicles > AIGameSettings.GetValue("vehicle.max_trains")) {
				local month = AIDate.GetMonth(AIDate.GetCurrentDate());
				if (lastmonthwarnraillimit != month) {
					cManager.LogError("We have already reached the train limit!");
					lastmonthwarnraillimit = month;
				}
				success = false;
			}
			local length = cBuilder.GetRailRoutePlatformLength(builder.stasrc, builder.stadst, builder.stapass) * 2 - 2;
			success = success && builder.BuildAndStartTrains(1, length, engine, wagon, extra_wagon, mainvehicle, false, prod1_percent);
			break;

		case AIVehicle.VT_ROAD:
			local roadvehicles = MyAIVehicleList_RoadVehs();
			// Do not try to add one if we have already reached the road vehicle limit
			if (roadvehicles.Count() + reserved_vehicles > AIGameSettings.GetValue("vehicle.max_roadveh")) {
				local month = AIDate.GetMonth(AIDate.GetCurrentDate());
				if (lastmonthwarnroadlimit != month) {
					cManager.LogError("We have already reached the road vehicle limit!");
					lastmonthwarnroadlimit = month;
				}
				success = false;
			}
			success = success && builder.BuildAndStartVehicles(engine, 1, mainvehicle);
			break;

		case AIVehicle.VT_AIR:
			local planes = MyAIVehicleList_Planes();
			// Do not try to add one if we have already reached the aircraft limit
			if (planes.Count() + reserved_vehicles > AIGameSettings.GetValue("vehicle.max_aircraft")) {
				local month = AIDate.GetMonth(AIDate.GetCurrentDate());
				if (lastmonthwarnairlimit != month) {
					cManager.LogError("We have already reached the aircraft limit!");
					lastmonthwarnairlimit = month;
				}
				success = false;
			}
			success = success && builder.BuildAndStartVehicles(engine, 1, mainvehicle);
			break;
	}
	builder = null;
	return success;
}

function cManager::ReplaceVehicle(vehicle)
{
	local replaced = false;
	local group = AIVehicle.GetGroupID(vehicle);
	local route = root.routes[root.groups.GetValue(group)];
	local engine = null;
	local wagon = null;
	local wagoncrg = route.crg;
	local wagonminspeed = null;
	local extra_wagon = null;
	local railtype = AIRail.GetCurrentRailType();
	local vehtype = AIVehicle.GetVehicleType(vehicle);
	local platform;
	local engine_count = 1;
	// Choose a new engine
	switch (vehtype) {
		case AIVehicle.VT_RAIL:
			AIRail.SetCurrentRailType(route.railtype);
			platform = cBuilder.GetRailRoutePlatformLength(route.stasrc, route.stadst, route.stapas);
			if (route.last_date < AIDate.GetCurrentDate() - 60) {
				wagon = MyTrains.ChooseWagon(route.crg, root.engineblacklist);
				extra_wagon = MyTrains.ChooseWagon(route.extracrg, root.engineblacklist);
				if (wagon != null && (route.extracrg == null || extra_wagon != null)) {
					wagonminspeed = wagon;
					if (extra_wagon!= null) {
						if (AIEngine.GetMaxSpeed(wagon) > AIEngine.GetMaxSpeed(extra_wagon)) {
							wagonminspeed = extra_wagon;
							wagoncrg = route.extracrg;
						}
					}
					engine = MyTrains.ChooseTrainEngine(wagoncrg, AIMap.DistanceManhattan(AIStation.GetLocation(route.stasrc), AIStation.GetLocation(route.stadst)), wagonminspeed, platform * 2 - 1, root.engineblacklist);
					engine_count = cBuilder.GetNumEnginesNeeded(engine, route.homedepot, platform * 2 - 1, route.slopes, wagon, route.crg, extra_wagon, route.extracrg);
					route.last_wagon = wagon;
					route.last_extra_wagon = extra_wagon;
					route.last_engine = engine;
					route.last_date = AIDate.GetCurrentDate();
				}
			} else {
				wagon = route.last_wagon;
				extra_wagon = route.last_extra_wagon;
				engine = route.last_engine;
				engine_count = cBuilder.GetNumEnginesNeeded(engine, route.homedepot, platform * 2 - 1, route.slopes, wagon, route.crg, extra_wagon, route.extracrg);
			}
			break;
		case AIVehicle.VT_ROAD:
			engine = MyRoadVehs.ChooseRoadVeh(route.crg);
			break;
		case AIVehicle.VT_AIR:
			local srctype = AIAirport.GetAirportType(AIStation.GetLocation(route.stasrc));
			local dsttype = AIAirport.GetAirportType(AIStation.GetLocation(route.stadst));
			local is_small = MyAIAirport.IsSmallAirport(srctype) || MyAIAirport.IsSmallAirport(dsttype);
			engine = MyPlanes.ChoosePlane(route.crg, is_small, AIOrder.GetOrderDistance(AIVehicle.VT_AIR, AIStation.GetLocation(route.stasrc), AIStation.GetLocation(route.stadst)), false);
			break;
	}
	local vehicles = AIVehicleList_Group(group);
	local ordervehicle = null;
	// Choose a vehicle to share orders with
	foreach (nextveh, dummy in vehicles) {
		ordervehicle = nextveh;
		// Don't share orders with the vehicle which will be sold
		if (nextveh != vehicle)	break;
	}
	if (ordervehicle == vehicle) ordervehicle = null;
	if (AIVehicle.GetVehicleType(vehicle) == AIVehicle.VT_RAIL) {
		if (engine != null && wagon != null && (Banker.GetMaxBankBalance() > AIEngine.GetPrice(engine) * engine_count + 2 * platform * AIEngine.GetPrice(wagon) + Banker.GetMinimumCashNeeded())) {
			// Sell the train
			if (!cManager.AddVehicle(route, ordervehicle, engine, wagon, extra_wagon, true)) {
				cManager.LogError("Error found when adding new vehicle!");
				AIVehicle.StartStopVehicle(vehicle);
			} else {
				AIVehicle.SellWagonChain(vehicle, 0);
				replaced = true;
			}
		} else {
			// Restart the train if we cannot afford to replace it
			AIVehicle.StartStopVehicle(vehicle);
		}
		// Restore the previous railtype
		AIRail.SetCurrentRailType(railtype);
	} else {
		if (engine != null && (Banker.GetMaxBankBalance() > AIEngine.GetPrice(engine))) {
			if (!cManager.AddVehicle(route, ordervehicle, engine, null, null, true)) {
				cManager.LogError("Error found when adding new vehicle!");
				AIVehicle.StartStopVehicle(vehicle);
			} else {
				AIVehicle.SellVehicle(vehicle);
				replaced = true;
			}
		} else {
			AIVehicle.StartStopVehicle(vehicle);
		}
	}
	todepotlist.RemoveItem(vehicle);
	return replaced;
}

function cManager::CheckDefaultGroup()
{
	local vehtypes = [AIVehicle.VT_ROAD, AIVehicle.VT_RAIL, AIVehicle.VT_AIR];
	for (local x = 0; x < 3; x++) {
		// The same algorithm is used for all three vehicle types
		local vehicles = AIVehicleList_DefaultGroup(vehtypes[x]);
		vehicles.Valuate(AIVehicle.IsStoppedInDepot);
		vehicles.KeepValue(1);
		foreach (vehicle, dummy in vehicles) {
			// Check for vehicles sitting in the depot.
			if (AIVehicle.GetProfitThisYear(vehicle) != 0 || AIVehicle.GetProfitLastYear(vehicle) != 0 || AIVehicle.GetAge(vehicle) < 60) continue;
			if (todepotlist.HasItem(vehicle)) {
				todepotlist.RemoveItem(vehicle);
				AIVehicle.StartStopVehicle(vehicle);
			} else {
				LogWarning("Sold " + AIVehicle.GetName(vehicle) + ", as it has been sitting in the depot for ages.");
				if (vehtypes[x] == AIVehicle.VT_RAIL) {
					AIVehicle.SellWagonChain(vehicle, 0);
				} else {
					AIVehicle.SellVehicle(vehicle);
				}
			}
		}
	}
}

function cManager::CheckTodepotlist()
{
	// This is needed so as not to modify the todepotlist while iterating through it
	local itemstoremove = [];
	foreach (vehicle, dummy in todepotlist) {
		// Obviously shouldn't be there if it's not even valid
		if (!AIVehicle.IsValidVehicle(vehicle)) {
			LogWarning("There was an invalid vehicle in the todpeotlist.");
			itemstoremove.push(vehicle);
			continue;
		}
		// Everything is OK if it has already reached the depot
		if (AIVehicle.IsStoppedInDepot(vehicle)) continue;
		// Check its destination
		local vehicle_destination = AIOrder.GetOrderDestination(vehicle, AIOrder.ORDER_CURRENT);
		switch (AIVehicle.GetVehicleType(vehicle)) {
			case AIVehicle.VT_ROAD:
				if (!AIRoad.IsRoadDepotTile(vehicle_destination)) {
					itemstoremove.push(vehicle);
					LogWarning("" + AIVehicle.GetName(vehicle) + " is not heading for a depot although it is listed in the todepotlist.");
				}
				break;

			case AIVehicle.VT_RAIL:
				if (!AIRail.IsRailDepotTile(vehicle_destination)) {
					itemstoremove.push(vehicle);
					LogWarning("" + AIVehicle.GetName(vehicle) + " is not heading for a depot although it is listed in the todepotlist.");
				}
				break;

			case AIVehicle.VT_AIR:
				if (!AIAirport.IsHangarTile(vehicle_destination)) {
					itemstoremove.push(vehicle);
					LogWarning("" + AIVehicle.GetName(vehicle) + " is not heading for a hangar although it is listed in the todepotlist.");
				}
				break;
		}
	}
	foreach (item in itemstoremove) {
		todepotlist.RemoveItem(item);
	}
}

function cManager::SendVehicleToDepot(vehicle) {
	local ret;
	switch (AIVehicle.GetVehicleType(vehicle)) {
		case AIVehicle.VT_ROAD:
			ret = cManager.SendRoadVehcToDepot(vehicle);
		break;
		case AIVehicle.VT_RAIL:
			ret = cManager.SendTrainToDepot(vehicle);
		break;
		case AIVehicle.VT_AIR:
			ret = AIVehicle.SendVehicleToDepot(vehicle);
		break;
	}
	return ret;
}

function cManager::SendTrainToDepot(vehicle)
{
	if (!AIVehicle.SendVehicleToDepot(vehicle)) {
		// Don't reverse if we are using PBS because reversed trains can block entire route.
		if (AISettings.IsSignalTypePBS()) return false;
		else {
			// Maybe the train only needs to be reversed to find a depot
			AIVehicle.ReverseVehicle(vehicle);
			AIController.Sleep(75);
			if (!AIVehicle.SendVehicleToDepot(vehicle)) {
				AIVehicle.ReverseVehicle(vehicle);
				return false;
			}
		}
	}
	return true;
}

function cManager::SendRoadVehcToDepot(vehicle)
{
	if (!AIVehicle.SendVehicleToDepot(vehicle)) {
		// Maybe the vehicle only needs to be reversed to find a depot
		AIVehicle.ReverseVehicle(vehicle);
		AIController.Sleep(75);
		if (!AIVehicle.SendVehicleToDepot(vehicle)) {
			AIVehicle.ReverseVehicle(vehicle);
			return false;
		}
	}
	return true;
}

function cManager::SendAllVehiclesToSell(list)
{
	foreach (vehicle, dummy in list) {
		if (todepotlist.HasItem(vehicle)) continue;
		if (!SendVehicleToDepot(vehicle)) continue;
		todepotlist.AddItem(vehicle, SuperSimpleAI.TD_SELL);
		LogInfo(AIVehicle.GetName(vehicle) + " is sending it to the depot because the route was closed");
	}
}

function cManager::PrintLog()
{
	return AISettings.GetAISetting("cManager_log", true);
}

function cManager::Debug()
{
	return (cManager.PrintLog()) ? AISettings.GetAISetting("cManager_log_debug", false) : false;
}
