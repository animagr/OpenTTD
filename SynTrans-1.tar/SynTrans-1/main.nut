/*
 * This file is part of SynTrans, which is an AI for OpenTTD
 *
 * SynTrans is free software; you can redistribute it and/or modify it 
 * under the terms of the GNU General Public License as published by
 * the Free Software Foundation; version 2 of the License
 *
 * SynTrans is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with SynTrans; If not, see <http://www.gnu.org/licenses/> or
 * write to the Free Software Foundation, Inc., 51 Franklin Street, 
 * Fifth Floor, Boston, MA 02110-1301 USA.
 *
 */
// Add all the files for libraries here
import("util.superlib","SuperLib",13);
import("pathfinder.road", "RoadPathFinder", 3);
// Add all your files here
require("network.nut");
require("town.nut");
//require("util.nut");

Result <- SuperLib.Result;
Log <- SuperLib.Log;
Helper <- SuperLib.Helper;
ScoreList <- SuperLib.ScoreList;
Money <- SuperLib.Money;
Tile <- SuperLib.Tile;
Direction <- SuperLib.Direction;
Engine <- SuperLib.Engine;
Vehicle <- SuperLib.Vehicle;
Station <- SuperLib.Station;
Airport <- SuperLib.Airport;
Industry <- SuperLib.Industry;
//Town <- SuperLib.Town;
Order <- SuperLib.Order;
OrderList <- SuperLib.OrderList;
Road <- SuperLib.Road;
RoadBuilder <- SuperLib.RoadBuilder;

aiInstance <- null;
 
 // Add all the files for the entire project here
 // ex. require("globals.nut");
 
 class SynTrans extends AIController {
	networks = null;
	airnet = null;
	enableAir = null;
	saved = null;
	constructor() {
		networks = [];
		enableAir = true;
		saved = false;
		//airnet = AirNet();
	}
	function Start();
	function Save();
	function Load(version,data);
}

function SynTrans::Start()
{
	this.Sleep(5);
	aiInstance = this;
	AIRoad.SetCurrentRoadType(AIRoad.ROADTYPE_ROAD);
	Log.Info("SynTrans Started");
	if(this.saved == true) {
		Log.Info("Loading networks...");
		local stationlist = null;
		// Load RoadNetwork
		if(!Vehicle.IsVehicleTypeDisabledByAISettings(AIVehicle.VT_ROAD)) {
			local depots = AIDepotList(AITile.TRANSPORT_ROAD);
			local newNet=Network(AIVehicle.VT_ROAD);
			stationlist = AIStationList(AIStation.STATION_BUS_STOP);
			foreach(station, _ in stationlist)
			{
				local town = AIStation.GetNearestTown(station);
				Log.Info("Processing town " + AITown.GetName(town));
				//newNet.AddTown(town);
				local theTown = Town(town,AIStation.STATION_BUS_STOP);
				theTown.stations.append(station);
				// Find the depot for the station... it should not be that far away
				//local tiles = Tile.MakeTileRectAroundTile(AIStation.GetLocation(station),20);
				foreach(depot, _ in depots) {
					local dtilex = AIMap.GetTileX(depot);
					Log.Info("Depot Tile X: " + dtilex);
					local dtiley = AIMap.GetTileY(depot);
					Log.Info("Depot Tile Y: " + dtiley);
					local stilex = AIMap.GetTileX(AIStation.GetLocation(station));
					Log.Info("Station Tile X: " + stilex);
					local stiley = AIMap.GetTileY(AIStation.GetLocation(station));
					Log.Info("Station Tile Y: " + stiley);
					for(local i = 10;i < 100;i+=5) {
						if(stilex - i < dtilex && stilex + i > dtilex && stiley - i < dtilex && stiley + i > dtiley) {
							theTown.depot = depot;
							continue;
						}
					}
					if(!theTown.depot) Log.Error("Could not find a depot for this city.  I wonder why...");
				}
				newNet.towns.append(theTown);
			}
			newNet.defaultEngine=Engine.GetEngine_PAXLink(0,AIVehicle.VT_ROAD);
			networks.append(newNet);
		}
		// Load AirNetwork
		if(!Vehicle.IsVehicleTypeDisabledByAISettings(AIVehicle.VT_AIR)) {
			airnet=Network(AIVehicle.VT_AIR);
			stationlist = AIStationList(AIStation.STATION_AIRPORT);
			foreach(station, _ in stationlist)
			{
				local town = AIStation.GetNearestTown(station);
				Log.Info("Processing town " + AITown.GetName(town));
				//airnet.AddTown(town);
				local theTown = Town(town,AIStation.STATION_AIRPORT);
				theTown.stations.append(station);
				theTown.depot = Airport.GetHangarTile(station);
				airnet.towns.append(theTown);
			}
			airnet.defaultEngine=Engine.GetEngine_PAXLink(0,AIVehicle.VT_AIR);
		}
	} else {
		if(Vehicle.IsVehicleTypeDisabledByAISettings(AIVehicle.VT_ROAD) && Vehicle.IsVehicleTypeDisabledByAISettings(AIVehicle.VT_AIR)) {
			Log.Error("This is a road and air only AI.  Please enable AI these building in Advanced settings!");
		}
		// Name the company
		if(!AICompany.SetName("Synchronized Transport Inc.")) {
			if(!AICompany.SetName("Another Synchronized Transport Inc.")) {
				if(!AICompany.SetName("Yet Another Synchronized Transport Inc.")) {
					local i=2;
					while(!AICompany.SetName("Synchronized Transport Copier #" + i)) i++;
				}
			}
		}
		// Make initial network
		if(!Vehicle.IsVehicleTypeDisabledByAISettings(AIVehicle.VT_ROAD)) {
			local newNet=Network(AIVehicle.VT_ROAD);
			networks.append(newNet);
			this.enableAir = true;
		}
		// Make (but dont start) Airnet
		if(!Vehicle.IsVehicleTypeDisabledByAISettings(AIVehicle.VT_AIR)) airnet=Network(AIVehicle.VT_AIR);
	}
	local townlist;
	local networkStart;
	local event;
	while(true)
	{
		// Manage events...
		while(AIEventController.IsEventWaiting()) {
			event=AIEventController.GetNextEvent();
			switch(event.GetEventType()) {
				case AIEvent.AI_ET_ENGINE_PREVIEW:
					local preview=AIEventEnginePreview.Convert(event);
					preview.AcceptPreview();
					Log.Info("Accepted preview for vehicle " + preview.GetName());
					break;
			}
		}
		if(!Vehicle.IsVehicleTypeDisabledByAISettings(AIVehicle.VT_ROAD)) foreach(network in networks) network.ManageNetwork();
		if(!Vehicle.IsVehicleTypeDisabledByAISettings(AIVehicle.VT_AIR)) if(enableAir) airnet.ManageNetwork();
		// Should we build a new network?
		if(!Vehicle.IsVehicleTypeDisabledByAISettings(AIVehicle.VT_ROAD)) {
		if(AIController.GetSetting("max_networks") > networks.len()) {
				if(AICompany.GetBankBalance(AICompany.COMPANY_SELF) > 250000) {
					Log.Info("==========BUILDING NEW NETWORK!==========");
					townlist = AITownList();
					// take out the cities we already own
					foreach(network in networks) {
						foreach(town in network.towns) {
							townlist.RemoveItem(town.id);
						}
					}
					// now find the biggest city
					townlist.Valuate(AITown.GetPopulation)
					townlist.Sort(AIList.SORT_BY_VALUE, false);
					networkStart=townlist.Begin();
					local newNet=Network(AIVehicle.VT_ROAD,networkStart);
					networks.append(newNet);
				}
			}
		}
		/*if(AICompany.GetBankBalance(AICompany.COMPANY_SELF)>500000 && !enableAir) {
			Log.Info("==========STARTING AIRCRAFT SYSTEM==========");
			enableAir=true;
		}*/
		Log.Info("Waiting...");
		this.Sleep(500);
	}
}

function SynTrans::Save()
{
	local thetable = {};
	return thetable;
}

function SynTrans::Load(version,data)
{
	this.saved = true;
}
