/*
 * This file is part of SynTrans, which is an AI for OpenTTD
 *
 * SynTrans is free software; you can redistribute it and/or modify it 
 * under the terms of the GNU General Public License as published by
 * the Free Software Foundation; version 2 of the License
 *
 * SynTrans is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with SynTrans; If not, see <http://www.gnu.org/licenses/> or
 * write to the Free Software Foundation, Inc., 51 Franklin Street, 
 * Fifth Floor, Boston, MA 02110-1301 USA.
 *
 */

class Network
{
	lastVehicleManage = null;
	lastVehicleBuild = null;
	lastNewTown = null;
	lastUpdateEngine = null;
	lastStartUpgrade = null;
	towns = null;
	blacklist = null;
	vehicles = null;
	defaultEngine = null;
	center = null;
	size = null;
	type = null;
	replace = null;
	noReplace = null;
	constructor(vtype,epicenter = null) {
		this.towns      = [];
		this.vehicles   = [];
		this.blacklist  = AIList();
		this.defaultEngine = null;
		this.center = epicenter;
		this.size = 1;
		this.type = vtype;
	}
	function ManageNetwork();
	function ManageVehicles();
	function CreateLink();
	function BuyVehicles(depot,engine,number,order1,order2);
	function SellVehicle(vehicle);
	function FindTown(chosenCity = null, desprate = false);
	function FindCloseConnection(town);
	function AddTown(theTown);
	function LeaveTown(index);
	function Connect(point1,point2);
	function PerformFullUpgrade();
	function ExpandStation(station = null);
}

// Function from TutorialAI's Road Tutorial
function TownDistValuator(town1,town2,targetDistance)
{
	local myval=Helper.Abs(AIMap.DistanceManhattan(AITown.GetLocation(town1), AITown.GetLocation(town2))-targetDistance);
	return myval;
}

function Network::ManageNetwork()
{
	Log.Info("=========================================");
	Log.Info("==========MANAGING NEXT NETWORK==========");
	Log.Info("=========================================");
	if(type==AIVehicle.VT_AIR) Log.Warning("This is AIRNET!!!");
	// Verify there is no shortage on the vehicle limit
	if(Vehicle.GetVehiclesLeft(AIVehicle.VT_ROAD)<50 && this.type == AIVehicle.VT_ROAD) {
		AILog.Warning("Road vehicle Limit Reached!  Please increase the vehicle limit in the advanced settings.  Until then, this AI will do nothing regarding road vehicles.");
		//AIController.Sleep(1000);
		return;
	}
	if(Vehicle.GetVehiclesLeft(AIVehicle.VT_AIR)<20 && this.type == AIVehicle.VT_AIR) {
		AILog.Warning("Aircraft vehicle Limit Reached!  Please increase the vehicle limit in the advanced settings.  Until then, this AI will do nothing regarding aircraft.");
		//AIController.Sleep(1000);
		return;
	}
	if(this.towns.len()==0) {
		Log.Info("======================Building First City====");
		this.defaultEngine=Engine.GetEngine_PAXLink(0,type);
		this.lastUpdateEngine=AIController.GetTick();
		Log.Info("Default engine is " + this.defaultEngine);
		local town1;
		local townlist=AITownList();
		townlist.Valuate(AITown.GetPopulation);
		if(type == AIVehicle.VT_AIR) townlist.RemoveAboveValue(10000);
		townlist.Sort(AIList.SORT_BY_VALUE,false);
		townlist.RemoveList(this.blacklist);
		if(center==null) {
			Log.Info("No city specified, finding instead");
			town1=townlist.Begin();
		}
		else {
			town1=this.center;
			townlist.Begin();
		}
		if(town1==null) Log.Error("Cannot create initial city");
		this.center=AITown.GetLocation(town1);
		local result=this.AddTown(town1);
		if(!result) {
			Log.Warning("Failed to build the inital city.  Leaving and finding a new one next time we have the chance on this network.");
			this.blacklist.AddItem(town1,0);
			this.center=null;
			return;
		}
		if(type != AIVehicle.VT_AIR) this.ExpandStation(towns[0].stations[0]);
		Log.Info("First City built");
		local town2=this.FindTown(towns[0],true);
		if(!town2) {
			Log.Info("Failed to build airport in second town.  Will retry next time");
			this.LeaveTown(0);
			this.blacklist.AddItem(town1,0);
			this.center = null;
			return;
		}
		//AddTown(town2);
		//Connect(town1,town2);
	}
	if(AICompany.GetBankBalance(AICompany.COMPANY_SELF)>20000+(AIEngine.GetPrice(defaultEngine)*2) && this.lastNewTown<AIController.GetTick()-2000) this.FindTown();
	if(this.replace) this.PerformFullUpgrade();
	else {
		if(this.lastNewTown < AIController.GetTick()-3000) {
			Log.Info("Finding a new town because we havent added one in awhile...");
			this.FindTown();
		}
		this.ManageVehicles();
	}
}

function Network::ManageVehicles() {
	Log.Info("Managing Vehicles...");
	// Check for new defaultEngine every once and awhile...
	if(this.lastUpdateEngine<AIController.GetTick()-10000) {
		Log.Warning("Checking for a new default engine...");
		local newEngine=Engine.GetEngine_PAXLink(0,type);
		if(newEngine!=this.defaultEngine) {
			AILog.Info("Switching to " + AIEngine.GetName(newEngine))
			local oldEngine = this.defaultEngine;
			this.defaultEngine = newEngine;
			this.noReplace = 0;
			local upgrade = true;
			this.lastStartUpgrade = AIController.GetTick();
			// While we are at it check if it is necisary to mass upgrade vehicles
			if(AICompany.GetBankBalance(AICompany.COMPANY_SELF) > (AIEngine.GetPrice(defaultEngine) * this.vehicles.len()) - (AIEngine.GetPrice(oldEngine) * this.vehicles.len())) this.PerformFullUpgrade();
			else upgrade = false;
			// If this is the aircraft network, might as well upgrade stations as well if possible
			if(upgrade && type == AIVehicle.VT_AIR && AICompany.GetBankBalance(AICompany.COMPANY_SELF) > 2000 * this.towns.len()) this.ExpandStation();
		}
		this.lastUpdateEngine = AIController.GetTick();
	}
	local frontTiles;
	local i=0;
	for(local i = 0;i < this.vehicles.len();i++) {
		// Get rid of the sold vehicles in the depot
		if(AIVehicle.IsStoppedInDepot(vehicles[i])) {
			AIVehicle.SellVehicle(vehicles[i]);
			this.vehicles.remove(i);
			continue;
		}
		// Sell non-profitable vehicles
		if(AIVehicle.GetProfitLastYear(vehicles[i])<0 && AIVehicle.GetAge(vehicles[i])>365) {
			Log.Info("Sending " + AIVehicle.GetName(vehicles[i]) + " due to lack of income from vehicle");
			AIVehicle.SendVehicleToDepot(vehicles[i]);
		}
	}
	local usedTowns = AIList();
	foreach(town in this.towns) {
		// check, if more than 30 people are waiting at this station, and suspended is on, turn it off
		if(town.suspended && AIStation.GetCargoWaiting(town.stations[0],Helper.GetPAXCargo())>30) {
			Log.Info("Town is no longer overloaded, un suspendeding");
			town.suspended = false;
		}
		// if town is already suspended, than why bother spending the time to figure out if it needs more vehicles?
		if(town.suspended) continue;
		local skip = false;
		// check to see if the town has already been added vehicles to
		foreach(used, _ in usedTowns) {
			if(town.id == used) {
				Log.Warning("Found used town " + AITown.GetName());
				skip = true;
			}
		}
		if(skip) continue;
		Log.Info("Checking to improve town " + AITown.GetName(town.id));
		// Grow the station
		local numTiles;
		local numVehicleTiles = 0;
		// check the front tile of every singe station peice.
		if(type == AIVehicle.VT_ROAD) {
			foreach(stationpiece, _ in Station.GetRoadFrontTiles(town.stations[0])) {
				local stationtiles=Tile.MakeTileRectAroundTile(AIStation.GetLocation(town.stations[0]),4);
				stationtiles.Valuate(AIRoad.IsRoadTile);
				stationtiles.KeepValue(1);
				numTiles=stationtiles.Count();
				// Loop to see if vehicles are on each tile, if numVehicleTiles>0.5*numTiles->grow station
				local vehiclelist;
				foreach(tile, _ in stationtiles) {
					vehiclelist=Vehicle.GetVehiclesAtTile(tile);
					if(!vehiclelist.IsEmpty()) numVehicleTiles++;
				}
			}
			Log.Info("Number of road tiles around station: " + numTiles);
			Log.Info("Number of vehicles on those road tiles: " + numVehicleTiles);
			local stationPlace=AITileList_StationType(town.stations[0],AIStation.STATION_BUS_STOP);
			local good=true;
			foreach(stationPeice, item in stationPlace) {
				if(Vehicle.GetVehiclesAtTile(stationPeice).Count()<2) good=false;
			}
			if(numVehicleTiles>numTiles*0.15 && AITileList_StationType(town.stations[0],AIStation.STATION_BUS_STOP).Count()<5 && good) this.ExpandStation(town.stations[0]);
			// Control suspended attribute, to ensure not to many vehicles get sent to this station. like blacklist
			if(Station.GetRoadFrontTiles(town.stations[0]).Count()==5  && AIStation.GetCargoWaiting(town.stations[0],Helper.GetPAXCargo())<5) {
				Log.Info("Station is suspended.  Suspending the sending of vehicles to it");
				town.suspended=true;
			}
		}
		//frontTiles=Station.GetRoadFrontTiles(town.stations[0]);
		// Add more vehicles to the station
		if(AIStation.GetCargoWaiting(town.stations[0],Helper.GetPAXCargo())>AIEngine.GetCapacity(defaultEngine) || AIStation.GetCargoRating(town.stations[0],Helper.GetPAXCargo())<40) {
			// First off, always ensure to have a reasonable amount of cash :)
			if(!Money.MakeSureToHaveAmount(AIEngine.GetPrice(defaultEngine)*(AIStation.GetCargoWaiting(town.stations[0],Helper.GetPAXCargo())/AIEngine.GetCapacity(defaultEngine)))) {
				Log.Info("Not enough cash to create needed vehicles for now");
				continue;
			}
			// On the other hand, for aircraft, the AI should only build a maximum of 1 extra each month
			Log.Info("Buying more vehicles for " + AITown.GetName(town.id));
			// Variables to help us
			local destinations=[];
			local list;
			// Get each town that goes to this station
			local same=false;
			/*foreach(vehicle in this.vehicles) {
				if(Order.HasStationInOrders(vehicle,town.stations[0])) {
					list=Order.GetStationListFromOrders(vehicle);
					list.RemoveItem(town.stations[0]);
					// Ensure this station does not already exist
					foreach(destiny in destinations) {
						if(destiny==list.Begin()) same=true;
					}
					if(!same) destinations.append(list.Begin());
					same=false;
				}
			}*/ // This may help speed up the process of finding destinations considerably!
			Log.Info("LENGTH OF DEST: " + destinations.len());
			// OR find stations that are nearby this station
			local townprep=[];
			// Add items from our network (while we are at it scan previous destinations for suspended stations)
			foreach(otherTown in towns) {
				for(local i=0;i<destinations.len();i++) {
				Log.Info("TOWN SUSPENSION: " + otherTown.suspended);
					if(otherTown.stations[0]==destinations[i] && otherTown.suspended) {
						destinations.remove(i);
						i--;
					}
				}
				if(!otherTown.suspended) townprep.append(otherTown);
				AIController.Sleep(1);
			}
			Log.Info("LENGTH OF DEST: " + destinations.len());
			// Transfer vars to new townlist
			local townlist=AIList();
			foreach(moveTown in townprep) {
				if(AIStation.GetCargoWaiting(moveTown.stations[0],Helper.GetPAXCargo())<10) continue;
				else townlist.AddItem(moveTown.id,0);
			}
			Log.Info("COUNT BEFORE: " + townlist.Count());
			// Valuate to nearby towns (be a bit less restrictive of distance away
			if(type == AIVehicle.VT_ROAD) {
				townlist.Valuate(this.TownDistValuator,town.id,50);
				townlist.Sort(AIList.SORT_BY_VALUE, true);
				townlist.RemoveAboveValue(60);
			}
			else {
				townlist.Valuate(this.TownDistValuator,town.id,300);
				townlist.Sort(AIList.SORT_BY_VALUE, true);
				townlist.RemoveAboveValue(100);
			}
			Log.Info("COUNT AFTER: " + townlist.Count());
			// ReAdd to townprep
			local match=false;
			Log.Info("LENGTH OF DEST: " + destinations.len());
			// NOTE: In the future we may be able to get rid of that later loop for finding suspended functions by checking in this loop.  Another way to speed up this long process.
			for(local i=0;i<townprep.len();i++) {
				Log.Info("TOWN: " + AITown.GetName(townprep[i].id));
				foreach(changedTown, item in townlist) {
					if(townprep[i].id==changedTown) {
						match=true;
					}
					if(match) break;
				}
				Log.Info("MATCH: " + match);
				if(!match) {
					townprep.remove(i);
					i--;
				}
				match=false;
				AIController.Sleep(1);
			}
			// check one more for suspended stations
			for(local i=0;i<townprep.len();i++) {
				if(townprep[i].suspended) {
					Log.Info("FOUND SUSPENDED TOWN " + AITown.GetName(townprep[i].id));
					townprep.remove(i);
					i--;
				}
			}
			Log.Info("LENGTH OF TOWNPREP: " + townprep.len());
			// Finally, prevent the same station as the origin from being picked
			for(local i=0;i<townprep.len();i++) {
				if(town.stations[0]==townprep[i].stations[0]) {
					townprep.remove(i);
					i--;
				}
			}
			// Add to destinations
			foreach(nextTown in townprep) destinations.append(nextTown.stations[0]);
			Log.Info("LENGTH OF DEST: " + destinations.len());
			// Ensure it is not empty
			if(destinations.len()==0) {
				Log.Warning("Could not find a good destination for this town");
				continue;
			}
			// Now find the station with the most passengers
			local bestStation=destinations[0];
			local bestWait=-1;
			foreach(station in destinations) {
				Log.Info("Checking station " + AIStation.GetName(station));
				if(AIStation.GetCargoWaiting(station,Helper.GetPAXCargo())>bestWait) {
					bestStation=station;
					bestWait=AIStation.GetCargoWaiting(station,Helper.GetPAXCargo());
				}
			}
			AIController.Sleep(1);
			Log.Info("BestStation: " + AIStation.GetName(bestStation));
			// If the best station does not have many passengers, make a new city connection
			if(!bestStation) continue;
			if(AIStation.GetCargoWaiting(bestStation,Helper.GetPAXCargo())<10/* && AICompany.GetBankBalance(AICompany.COMPANY_SELF)>20000+(AIEngine.GetPrice(defaultEngine)*2)*/) {
				local myResult;
				if(town.newStationTries>3) myResult=FindTown(town,true);
				else myResult=FindTown(town);
				//if(!myResult) town.newStationTries++; // test feature, needs work
				continue;
			}
			// Ensure there is a road between the two stations (if road network)
			if(type != AIVehicle.VT_AIR) {
				Log.Info("Checking roads...");
				local result = false;
				foreach(connection, _ in town.connections) {
					Log.Warning("I see station " + AIStation.GetName(connection));
					if(connection == bestStation) result = true;
				}
				//Log.Warning("After foreach loop...");
				if(!result) {
					Log.Info("Town is not connected to the other city.  Connecting it now...");
					if(!this.Connect(AIStation.GetLocation(town.stations[0]),AIStation.GetLocation(bestStation))) {
						Log.Warning("Could not connect roads.  Cancelling...");
						continue;
					}
					// Add town to the list of both towns
					town.connections.AddItem(bestStation,0);
					foreach(townp in townprep) {
						if(townp.stations[0] == bestStation) {
							Log.Warning("Adding to list of connected stations");
							townp.connections.AddItem(town.stations[0],0);
						}
					}
				}
				else Log.Info("Stations " + AIStation.GetName(town.stations[0]) + " and " + AIStation.GetName(bestStation) + " are already connected.");
			}
			Log.Info("Building the vehicles to " + AIStation.GetName(bestStation));
			// We now (finally) build the vehicles
			local number = AIStation.GetCargoWaiting(town.stations[0],Helper.GetPAXCargo())/AIEngine.GetCapacity(defaultEngine);
			if(number > 3 && type == AIVehicle.VT_AIR) number = 3;
			else if(number > 5) number = 5;
			if(AIStation.GetCargoRating(town.stations[0],Helper.GetPAXCargo())<40 && type==AIVehicle.VT_ROAD) this.BuyVehicles(town.depot,defaultEngine,2,town.stations[0],bestStation);
			else if(type == AIVehicle.VT_AIR) this.BuyVehicles(town.depot,defaultEngine,number,town.stations[0],bestStation);
			else this.BuyVehicles(town.depot,defaultEngine,number,town.stations[0],bestStation);
			// Wait a little
			AIController.Sleep(5);
		}
	}
	this.lastVehicleManage=AIController.GetTick();
}

function Network::CreateLink() {
	local newTown=FindTown();
	this.AddTown(newTown);
	local index=this.FindCloseConnection(town);
	this.Connect(AIStation.GetLocation(newTown.stations[0]),AIStation.GetLocation(towns[index].stations[0]));
}

function Network::BuyVehicles(depot,engine,number,order1,order2) {
	if(!depot || !engine) {
		Log.Warning("Cannot build vehicles because depot or engine is not valid");
	}
	Log.Info("Building " + number + " vehicles of " + AIEngine.GetName(engine));
	local newVehicle=AIVehicle.BuildVehicle(depot,engine);
	if(!AIVehicle.IsValidVehicle(newVehicle)) {
		Log.Warning("Could not build a vehicle: " + AIError.GetLastErrorString());
		return false;
	}
	this.vehicles.append(newVehicle);
	local orders=OrderList();
	orders.AddStop(order1,AIOrder.AIOF_FULL_LOAD);
	orders.AddStop(order2,AIOrder.AIOF_FULL_LOAD);
	orders.ApplyToVehicle(newVehicle);
	AIVehicle.StartStopVehicle(newVehicle);
	local nextVehicle;
	for(local i=1;i<number;i++) {
		nextVehicle=AIVehicle.CloneVehicle(depot,newVehicle,false);
		if(!AIVehicle.IsValidVehicle(nextVehicle)) {
			Log.Warning("Could not build a vehicle");
			continue;
		}
		this.vehicles.append(nextVehicle);
		AIVehicle.StartStopVehicle(nextVehicle);
	}
}

function Network::SellVehicle(vehicle) {
	Log.Info("Selling " + AIVehicle.GetName(vehicle));
	AIVehicle.SellVehicle(vehicle);
}

function Network::FindTown(chosenCity = null,desprate = false) {
	if(!Money.MakeSureToHaveAmount((AIEngine.GetPrice(defaultEngine) * 2) + (AIAirport.GetPrice(Airport.GetLastAvailableAirportType(Engine.GetEngine_PAXLink(0,AIVehicle.VT_AIR)))))) {
		Log.Warning("Do not have enough money to create city connection.");
		return false;
	}
	Log.Info("Finding a new town...");
	if(desprate) Log.Warning("We are desprate for a new town");
	// Choose the biggest outskirts city
	if(chosenCity==null) {
		local chosenWait=-1;
		Log.Info("Length: " + towns.len());
		foreach(town in this.towns) {
			if(/*town.outerLayer==true && */AIStation.GetCargoWaiting(town.stations[0],Helper.GetPAXCargo())>chosenWait) {
				chosenCity=town;
				chosenWait=AIStation.GetCargoWaiting(town.stations[0],Helper.GetPAXCargo());
			}
		}
	}
	Log.Info("Adding a new town for " + AITown.GetName(chosenCity.id));
	local townlist=AITownList();
	townlist.RemoveList(blacklist);
	foreach(town in this.towns) {
		townlist.RemoveItem(town.id);
	}
	// Remove towns from other networks if not aircraft network
	if(type != AIVehicle.VT_AIR) {
		foreach(network in aiInstance.networks) {
			foreach (town in network.towns) {
				townlist.RemoveItem(town.id);
			}
		}
	}
	townlist.Valuate(AITown.GetPopulation);
	townlist.RemoveBelowValue(500); //cities must be at least 500 in population in order to be considered for use!
	//Log.Warning("townlist.Begin(): " + AITown.GetLocation(townlist.Begin()));
	//Log.Warning("chosenCity.id: " + AITown.GetLocation(chosenCity.id));
	//Log.Warning("Return of the locations: " + Helper.Abs(AIMap.DistanceSquare(AITown.GetLocation(townlist.Begin()),AITown.GetLocation(chosenCity.id))));
	local value=TownDistValuator(townlist.Begin(),chosenCity.id,50);
	//Log.Warning("Return of TownDistValuator: " + value);
	if(type == AIVehicle.VT_ROAD) townlist.Valuate(TownDistValuator, chosenCity.id, 50);
	else townlist.Valuate(TownDistValuator, chosenCity.id, 300);
	townlist.Sort(AIList.SORT_BY_VALUE, true);
	Log.Info("DUMP:  ");
	Log.Info(AITown.GetName(townlist.Begin()) + "  :  " + townlist.GetValue(townlist.Begin()));
	Log.Info(AITown.GetName(townlist.Next()) + "  :  " + townlist.GetValue(townlist.Next()));
	if(!desprate && type == AIVehicle.VT_AIR) townlist.RemoveAboveValue(100);
	else if(!desprate && type == AIVehicle.VT_ROAD) townlist.RemoveAboveValue(80);
	if(townlist.IsEmpty()) {
		AILog.Info("Could not find a good enough town to connect to this city.");
		return false;
	}
	local newTown=townlist.Begin();
	if(newTown==null) {
		Log.Warning("Could not connect to a new city in the network");
		return false;
	}
	// Now set up the city
	local builtTown=AddTown(newTown);
	if(!builtTown) {
		Log.Info("Because we could not build the town connecting the town is cancelled.");
		return false;
	}
	// expand the station
	if(type == AIVehicle.VT_ROAD) this.ExpandStation(builtTown.stations[0]);
	// If air then build a road between them
	if(type == AIVehicle.VT_ROAD) {
		local result=Connect(AIStation.GetLocation(chosenCity.stations[0]),AIStation.GetLocation(builtTown.stations[0]));
		if(!result) {
			Log.Info("Pathfinding failed.  Leaving Town...");
			this.blacklist.AddItem(this.towns[towns.len()-1].id,0);
			this.LeaveTown(towns.len()-1);
			return false;
		}
	}
	// Add the chosen town to the connected towns list
	builtTown.connections.AddItem(chosenCity.stations[0],0);
	chosenCity.connections.AddItem(builtTown.stations[0],0);
	// And now some vehicles
	BuyVehicles(builtTown.depot,defaultEngine,2,builtTown.stations[0],chosenCity.stations[0]);
	chosenCity.outerLayer=false;
	Log.Info("Finished building new link :D");
	this.lastNewTown=AIController.GetTick();
	return true;
}

function Network::FindCloseConnection(town) {
	
}

function Network::AddTown(theTown) {
	Log.Info("==========Adding town " + AITown.GetName(theTown) + "==========");
	local newTown;
	if(this.type == AIVehicle.VT_AIR) newTown = Town(theTown,AIStation.STATION_AIRPORT);
	else newTown = Town(theTown,AIStation.STATION_BUS_STOP);
	local result
	if(this.type == AIVehicle.VT_AIR) result=newTown.Begin(AIStation.STATION_AIRPORT);
	else result=newTown.Begin(AIStation.STATION_BUS_STOP);
	if(result) this.towns.append(newTown);
	else {
		Log.Info("Could not build the town...");
		return null;
	}
	return newTown;
}

function Network::LeaveTown(index) {
	this.towns[index].End();
	this.towns.remove(index);
}

function Network::Connect(point1,point2) {
	Log.Info("Connecting the points...");
	/*local pathfinder=RoadBuilder();
	pathfinder.Init(point1,point2,false,500);
	local result=pathfinder.ConnectTiles();
	if(result!=RoadBuilder.CONNECT_SUCCEEDED) return false;*/
	local convoy = ConvoyFunc();
	local result = convoy.BuildRoad(point1,point2);
	Log.Warning("Result: " + result);
	if(!result) return false;
	if(result < 1) return false;
	return true;
}

function Network::PerformFullUpgrade() {
	Log.Info("----------PERFORMING FULL UPGRADE----------");
	//Log.Warning("Full upgrade not yet implemented");
	// First look through all the vehicles, and find the ones not upgraded. from there, upgrade them
	if(!replace) {
		Log.Info("Beginning to upgrade vehicles...");
		foreach(vehicle in vehicles) {
			if(AIVehicle.GetEngineType(vehicle) != defaultEngine) AIVehicle.SendVehicleToDepot(vehicle);
		}
		replace = true;
	}
	// When this function is recalled, upgrade any vehicles that have entered the depot.
	else {
	Log.Info("Continuing to upgrade vehicles...");
	local done = true;
	local replaced = false;
	foreach(vehicle in vehicles) {
		if(AIVehicle.GetEngineType(vehicle) == defaultEngine) continue;
		else {
			done = false;
			if(AIVehicle.IsStoppedInDepot(vehicle)) {
				if(!Money.MakeSureToHaveAmount((AIEngine.GetPrice(defaultEngine)))) return;
				// Copy orders and depot
				local stationlist = Order.GetStationListFromOrders(vehicle);
				local origdepot = AIVehicle.GetLocation(vehicle);
				// Sell Vehicle
				AIVehicle.SellVehicle(vehicle);
				// Rebuild vehicle and send out
				this.BuyVehicles(origdepot,defaultEngine,1,stationlist.Begin(),stationlist.Next());
				//AIVehicle.StartStopVehicle(vehicle);
				replaced = true;
				//noReplace = 0;
			}
		}
	}
	if(!replaced) this.noReplace++;
		Log.Warning("NOREPLACE: " + this.noReplace);
		if(done || this.noReplace > 10 || this.lastStartUpgrade < AIController.GetTick()-10000) {
			this.replace = false;
			// make sure that vehicles are moving even if not upgraded
			foreach(vehicle in vehicles) {
			Log.Info("----------Finishing Upgrade Process----------");
			if(AIVehicle.IsStoppedInDepot(vehicle)) AIVehicle.StartStopVehicle(vehicle);
			}
		}
	}
}

function Network::ExpandStation(station = null) {
	// This function is equivalent to updating the station in airport mode
	if(type == AIVehicle.VT_ROAD) {
		Log.Info("Trying to expand station " + AIStation.GetName(station));
		local theResult=Road.GrowStationParallel(station,AIStation.STATION_BUS_STOP);
		if(Result.IsFail(theResult)) {
			Log.Info("Failed to grow station parallel, trying not paralell...");
			theResult=Road.GrowStation(station,AIStation.STATION_BUS_STOP);
			if(Result.IsFail(theResult)) Log.Warning("Failed to grow station :(");
		}
	}
	else {
		// if station is null, upgrade everything
		if(!station) {
			Log.Info("Expanding aircraft stations...");
			// Get perferred station
			local stype = Airport.GetLastAvailableAirportType(Engine.GetEngine_PAXLink(0,AIVehicle.VT_AIR));
			if(!stype) return;
			local airlist = [];
			airlist.append(stype);
			for(local i = 0;i < towns.len();i++) {
				if(AIAirport.GetAirportType(AIStation.GetLocation(towns[i].stations[0])) == stype) continue;
				local result = Airport.UpgradeAirportInTown(towns[i].id,towns[i].stations[0], airlist, Helper.GetPAXCargo(), Helper.GetPAXCargo());
				if(Result.IsFail(result)) {
					Log.Warning("Failed to upgrade station :(");
					if(result == Result.REBUILD_FAILED) {
						Log.Warning("Even worse, rebuild failed.  It is easiest for now just to leave the town.");
						this.LeaveTown(i);
					}
				}
			}
		}
	}
}
