/*
 * This file is part of SynTrans, which is an AI for OpenTTD
 *
 * SynTrans is free software; you can redistribute it and/or modify it 
 * under the terms of the GNU General Public License as published by
 * the Free Software Foundation; version 2 of the License
 *
 * SynTrans is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with SynTrans; If not, see <http://www.gnu.org/licenses/> or
 * write to the Free Software Foundation, Inc., 51 Franklin Street, 
 * Fifth Floor, Boston, MA 02110-1301 USA.
 *
 */
 
//function BuildBusStop(tile);
//function FindLineBusStopLocation(town, pass_cargo_id, estimate);
 
// The following functions in this class are from convoy ( I made some minor modifications to make this AI work with these functions)
 
class ConvoyFunc {
	err = null;
	constructor() {
		err = AIError.ERR_NONE;
	}
	function BuildRoad(start, target);
	function GetAdjacentTiles(tile);
	function BuildBusStop(tile);
	function FindLineBusStopLocation(town, pass_cargo_id, estimate);
}

function ConvoyFunc::BuildRoad(start, target)
{
//	Log.Warning("BuildRoad called");
	local retry_find   = false;	
	local plan_retries = 0;
	local pathfinder = RoadPathFinder();
	local path_len = 0;	

	if(start == null || target == null )	{
		Log.Warning("PathFinder: BuildRoad: null tiles");
		return false;
	}

	if( !AIMap.IsValidTile(start) || !AIMap.IsValidTile(target)) {
		Log.Warning("PF:BuildRoad: no valid tile" );
		return false;
	}
	do {
		retry_find = false;

		pathfinder.InitializePath([start], [target]);
		pathfinder.cost.slope = 50;
		local path = false;
		while (path == false) {
		  path = pathfinder.FindPath(100);
		  AIController.Sleep(1);
		}
//		AILog.Info("PathFinder: FindPath ready " + (path == null));
		while (path != null) {
			path_len = path_len + 1;	
			if (path.GetParent() != null) {
				local parnt = path.GetParent().GetTile();
				if (!AIRoad.AreRoadTilesConnected(path.GetTile(), parnt) 
					&& (!AIBridge.IsBridgeTile(path.GetTile()) 
						|| AIBridge.GetOtherBridgeEnd(path.GetTile()) != parnt)) {
					local retry_build = false;
					local build_retries = 0;	 
					do {
						retry_build = false;
						if (AIMap.DistanceManhattan(path.GetTile(), parnt) == 1 ) {
//						   AILog.Info("PathFinder: tiles " + 
//								AIMap.GetTileX(path.GetTile()) + " " + AIMap.GetTileY(path.GetTile()) +
//								AIMap.GetTileX(parnt) + " " + AIMap.GetTileY(parnt));
						local built_road = AIRoad.BuildRoad(path.GetTile(), parnt);
							if (!built_road) {
								err = AIError.GetLastError();
								switch (err) {
									/* ignore these errors */
									case AIError.ERR_NONE: 	
									case AIError.ERR_ALREADY_BUILT: 
										/* decrement retry counter, so it does not limit the nr of retries 
											else after 35 tiles over existing road, the building stops 
										*/	 									
										if (build_retries) build_retries = build_retries - 1;
									break;
									/* can't handle this locally, return unsuccessful */
									case AIError.ERR_PRECONDITION_FAILED:
									case AIError.ERR_NEWGRF_SUPPLIED_ERROR:
									case AIError.ERR_NOT_ENOUGH_CASH:  
									case AIError.ERR_LOCAL_AUTHORITY_REFUSES: 
										Log.Warning("Build road failed(fatal)"+ AIError.GetLastErrorString()+" "+
										AIMap.GetTileX(parnt)+" " + AIMap.GetTileY(parnt)
										+" "+AIMap.GetTileX(path.GetTile())+" " +	AIMap.GetTileY(path.GetTile())+" " + AITile.GetSlope(path.GetTile())+" " +
										AITile.GetSlope(parnt));
										return false;
									break;
									case AIError.ERR_VEHICLE_IN_THE_WAY: 
										Log.Warning("Build road failed (retry)"+ AIError.GetLastErrorString()+" "+
										AIMap.GetTileX(parnt)+" " + AIMap.GetTileY(parnt)
										+" "+AIMap.GetTileX(path.GetTile())+" " + AIMap.GetTileY(path.GetTile())+" " + AITile.GetSlope(path.GetTile())+" " +
										AITile.GetSlope(parnt));	
										AIController.Sleep(1);
										retry_build = true;
									break;
									case AIError.ERR_AREA_NOT_CLEAR: 	
										Log.Warning("Build road failed (demolish + retry)"+ AIError.GetLastErrorString()+" "+
										AIMap.GetTileX(parnt)+" " + AIMap.GetTileY(parnt)
										+" "+AIMap.GetTileX(path.GetTile())+" " +
										  AIMap.GetTileY(path.GetTile())+" " + AITile.GetSlope(path.GetTile())+" " +
										AITile.GetSlope(parnt));	
										AITile.DemolishTile(path.GetTile());
										retry_build = false;
										retry_find = true;
										break;
									case AIError.ERR_OWNED_BY_ANOTHER_COMPANY :
									case AIError.ERR_FLAT_LAND_REQUIRED: 	
									case AIError.ERR_LAND_SLOPED_WRONG: 	
									case AIError.ERR_SITE_UNSUITABLE: 	
									case AIError.ERR_TOO_CLOSE_TO_EDGE: 
										Log.Warning("Build road failed (replan)"+ AIError.GetLastErrorString()+" "+
										AIMap.GetTileX(parnt)+" " + AIMap.GetTileY(parnt)
										+" "+AIMap.GetTileX(path.GetTile())+" " + AIMap.GetTileY(path.GetTile())+" " + AITile.GetSlope(path.GetTile())+" " +
										AITile.GetSlope(parnt));	
										retry_build = false;
										retry_find = true;
										break;
									case AIError.ERR_UNKNOWN:
									default:
										Log.Warning("Build road failed (replan)"+ AIError.GetLastErrorString()+" "+
										AIMap.GetTileX(parnt)+" " + AIMap.GetTileY(parnt)
										+" "+AIMap.GetTileX(path.GetTile())+" " +AIMap.GetTileY(path.GetTile())+" " + AITile.GetSlope(path.GetTile())+" " +
										AITile.GetSlope(parnt));	
										retry_find = true;
										break;
								}
							} 
							build_retries++;
						}
						else {
							Log.Info("PathFinder: build bridge");
						  /* Build a bridge or tunnel. */
						  if (!AIBridge.IsBridgeTile(path.GetTile()) && !AITunnel.IsTunnelTile(path.GetTile())) {
							/* If it was a road tile, demolish it first. Do this to work around expended roadbits. */
						 if (AIRoad.IsRoadTile(path.GetTile())) AITile.DemolishTile(path.GetTile());
						  if (AITunnel.GetOtherTunnelEnd(path.GetTile()) == parnt) {
								if (!AITunnel.BuildTunnel(AIVehicle.VT_ROAD, path.GetTile())) {
										Log.Warning("Build tunnel failed");
								}
						} else {
							local bridge_list = AIBridgeList_Length(AIMap.DistanceManhattan(path.GetTile(), parnt) + 1);
								bridge_list.Valuate(AIBridge.GetMaxSpeed);
								bridge_list.Sort(AIAbstractList.SORT_BY_VALUE, false);
							if (!AIBridge.BuildBridge(AIVehicle.VT_ROAD, bridge_list.Begin(), path.GetTile(), parnt)) {
										Log.Warning("Build bridge failed");
								}
								}
						}
						}	
					} while (retry_build && build_retries < 80 && !retry_find);
				}
			}
			path = path.GetParent();
		}
		plan_retries++;
	}	while (retry_find && (plan_retries < 10));
	return path_len;
}
 
function ConvoyFunc::GetAdjacentTiles(tile)
{
	local adjTiles = AITileList();
	
	adjTiles.AddTile(tile - AIMap.GetTileIndex(1,0));
	adjTiles.AddTile(tile - AIMap.GetTileIndex(0,1));
	adjTiles.AddTile(tile - AIMap.GetTileIndex(-1,0));
	adjTiles.AddTile(tile - AIMap.GetTileIndex(0,-1));
	
	return adjTiles;
}

function ConvoyFunc::BuildBusStop(tile)
{
	local found = false;
	local success = false;

	local adjacentTiles = this.GetAdjacentTiles(tile);

	for(local tile2 = adjacentTiles.Begin(); 
			adjacentTiles.HasNext() && !found; 
			tile2 = adjacentTiles.Next()) {
		if(AIRoad.IsRoadTile(tile2) ) {
			local count = 0;
			while(!success && (count < 100)){
				local pathlen = this.BuildRoad(tile2, tile);
//				AILog.Info("Build busstop pathlen " + pathlen);
				if (pathlen == 2) {
					success = true; 
				} else {
					count = count + 1;
				}
			}
			local truck = AIRoad.ROADVEHTYPE_BUS; 
			local adjacent = AIStation.STATION_NEW;
			if (success) {
				success = AIRoad.BuildRoadStation(tile, tile2, truck, adjacent);
			}
			found = true;
		}
	}

	if (!success) {
		Log.Warning("Build busstop failed "+ AIError.GetLastErrorString());
//		AISign.BuildSign(tile,"bbs");
	}
	return success;	
}

function ConvoyFunc::FindLineBusStopLocation(town, pass_cargo_id, estimate)
{
	local tl = AITileList();
	local aitile = null;
	local tile = AITown.GetLocation(town);
	local found = false;
	local ret_tile = null;
	
	tl.AddRectangle(tile + AIMap.GetTileIndex(-8, -8), tile + AIMap.GetTileIndex(8, 8));
	
	/* remove all tiles that are already covered by a station */
	local tl2 = AITileList();

	tl2.AddList(tl);
	tl2.Valuate(AIRoad.IsRoadStationTile);
	tl2.KeepValue(1);

	for (local rstl = tl2.Begin(); tl2.HasNext() ; rstl = tl2.Next()){
		/* Keep our own stations a bit apart */
		if (AITile.GetOwner(rstl) == AICompany.ResolveCompanyID(AICompany.COMPANY_SELF)) {
			tl.RemoveRectangle(rstl + AIMap.GetTileIndex(-4, -4), rstl + AIMap.GetTileIndex(4, 4));
		}
		else {    /* but don't be so modest with other players stations ... */
			tl.RemoveRectangle(rstl + AIMap.GetTileIndex(-1, -1), rstl + AIMap.GetTileIndex(1, 1));
		}
	}	 

	if (tl.Count()) {
		/* find all tiles that are next to a road tile */
		tl.Valuate(AIRoad.GetNeighbourRoadCount);	
		tl.KeepAboveValue(0);

		if (tl.Count()) {
			/* find all tiles that are not road */
	   	tl.Valuate(AIRoad.IsRoadTile);	
   	  	tl.KeepValue(0);
			if (tl.Count()) {
	   		/* find all tiles that are not sloped */
		   	tl.Valuate(AITile.GetSlope);	
   		   tl.KeepValue(0);
				if (tl.Count()) {
					tl.Valuate(AITile.GetCargoAcceptance, pass_cargo_id,
								 1, 1, 
								 AIStation.GetCoverageRadius (AIStation.STATION_BUS_STOP));
					for (aitile = tl.Begin(); tl.HasNext(); aitile = tl.Next()){
//						AISign.BuildSign(aitile,"ex"+tl.GetValue(aitile));
						if (tl.GetValue(aitile) >= 15){
  							found = AITile.IsBuildable(aitile);
							if (estimate) {
								found = true;
							}	
							if (!found)	{
								found = AITile.DemolishTile(aitile);
							}
							if (found) {
								ret_tile = aitile;
								break;
							}	
						}	
						else {
							Log.Info("Find busstop location, acceptance too low " + tl.GetValue(aitile));
						}
	   			}
				}
				else {
					Log.Info("Find busstop location, no unsloped tiles present");
				}
	   	}
			else {
				Log.Info("Find busstop location, no tiles that are not road present");
			}
	   }
		else {
			Log.Info("Find busstop location, no tiles next to road present");
		}
	}
	

	
	if (found) {
//		AISign.BuildSign(aitile,"ex"+tl.GetValue(aitile));
		return ret_tile;	
	}	
	else {
		return null;	
	}	
}

class Town
{
	id = null;
	outerLayer = null;
	stations = null;
	depot = null;
	suspended = null;
	newStationTries = null;
	stationType = null;
	connections = null;
	constructor(townid,stype) {
		this.id = townid;
		this.outerLayer = true;
		this.stations = [];
		this.depot = null;
		this.stationType = stype;
		this.connections = AIList();
	}
	function Begin(stationType);
	function BuildStation();
	function End();
}

function Town::Begin(stationType) {
	/*AILog.Warning("BUILDING STATION IN CITIES");
	local station=Road.BuildMagicDTRSNextToRoad(AITown.GetLocation(id),AIRoad.ROADTYPE_ROAD, 2,-1,-1,25,125);
	if(station.result) {
		this.stations.append(station.station_id);
		this.depot=station.depot_tile;
	}
	return station.result;*/  // DTRS OLD
	this.connections = AIList();
	Log.Info("Attempting to build station and depot");
	this.stationType=stationType;
	local stationId;
	if(this.stationType==AIStation.STATION_BUS_STOP) {
		local cfunctions = ConvoyFunc();
		local theTile = cfunctions.FindLineBusStopLocation(this.id, Helper.GetPAXCargo(), false);
		if(!theTile) {
			Log.Warning("Could not find a good place to build in " + this.id);
			return false;
		}
		local result = cfunctions.BuildBusStop(theTile);
		if(result) stationId = theTile;
	}
	else stationId=Airport.BuildAirportInTown(this.id,Airport.GetLastAvailableAirportType(Engine.GetEngine_PAXLink(0,AIVehicle.VT_AIR)),Helper.GetPAXCargo(),Helper.GetPAXCargo());
	if(!stationId) {
		Log.Warning("Could not build station in this city");
		return false;
	}
	local station;
	/*if(this.stationType != AIStation.STATION_BUS_STOP)*/ station=AIStation.GetStationID(stationId);
	//station = stationId;
	Log.Info("STATION NAME: " + AIStation.GetName(station));
	if(!AIStation.IsValidStation(station)) {
		Log.Info("Could not build the station");
		return false;
	}
	this.stations.append(station);
	if(this.stationType==AIStation.STATION_BUS_STOP) this.depot=Road.BuildDepotNextToRoad(stationId, 50, 150);
	else this.depot=Airport.GetHangarTile(station);
	if(!this.depot) {
		Log.Warning("Could not build depot!");
		return false;
	}
	this.suspended=false;
	this.newStationTries=0;
	return true;
}

function Town::BuildStation() {
	// Not yet implemented
	Log.Info("Empty Function");
}

function Town::End() {
	for(local i=0;i<this.stations.len();i++) {
		AIRoad.RemoveRoadStation(AIStation.GetLocation(this.stations[i]));
		while(AIStation.IsValidStation(this.stations[i])) AIRoad.RemoveRoadStation(AIStation.GetLocation(this.stations[i]));
	}
	AIRoad.RemoveRoadDepot(this.depot);
	this.id=null;
}
